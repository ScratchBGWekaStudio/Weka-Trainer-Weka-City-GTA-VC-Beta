# -*- coding: utf-8 -*-
"""
zheka_intro.py — збирає стартові відео для «Жека Сіті» з ОДНІЄЇ фотографії (JPG / PNG).

  Logo.mpg      — заставка «Scratch Studio»
  GTAtitles.mpg — «Scratch Studio Started»: фото оживає (камера, дихання, трава, пилинки,
                  світло), підпис «Йдемо зі мною», тихий звук

Потрібно: Pillow, numpy і ffmpeg (найпростіше:  pip install numpy imageio-ffmpeg).
Фото не малюється заново: рухається саме воно, без накладених «ефектів».
"""
import math
import os
import random
import shutil
import subprocess
import wave

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H, FPS, SR = 640, 480, 25, 44100
BW, BH = 1288, 966          # робоче полотно (4:3) із запасом для руху камери
CAT_PHOTO_NAME = "zheka_cat.jpg"   # фото кота з архіву: для нього відомий контур кота (дихання)

# контур кота у відносних координатах оригінального фото 1402x1122
CAT_POLY = [(385, 720), (392, 560), (470, 400), (555, 235), (560, 215), (610, 225), (700, 190), (850, 195),
            (915, 170), (925, 250), (935, 380), (920, 520), (880, 640), (850, 760), (840, 880), (790, 905),
            (745, 890), (740, 935), (640, 935), (620, 880), (590, 800), (520, 780), (430, 800)]
CAT_SRC = (1402, 1122)

FONTS = {
    "semi": ["/usr/share/fonts/opentype/inter/Inter-SemiBold.otf", r"C:\Windows\Fonts\seguisb.ttf",
             r"C:\Windows\Fonts\segoeuib.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"],
    "med": ["/usr/share/fonts/opentype/inter/Inter-Medium.otf", r"C:\Windows\Fonts\segoeui.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"],
    "light": ["/usr/share/fonts/opentype/inter/Inter-Light.otf", r"C:\Windows\Fonts\segoeuisl.ttf",
              r"C:\Windows\Fonts\segoeui.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"],
}


def pick_font(kind, size):
    for p in FONTS[kind]:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except OSError:
                pass
    return ImageFont.load_default()


def find_ffmpeg():
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        raise RuntimeError("Не знайдено ffmpeg. Встанови:  pip install imageio-ffmpeg")


def clamp(x, a=0.0, b=1.0):
    return max(a, min(b, x))


def smooth(x):
    x = clamp(x)
    return x * x * (3 - 2 * x)


# ------------------------------------------------------------------ сцена з фото
def bilinear(img, xs, ys):
    h, w = img.shape[:2]
    x0 = np.clip(np.floor(xs).astype(np.int32), 0, w - 2)
    y0 = np.clip(np.floor(ys).astype(np.int32), 0, h - 2)
    fx = np.clip(xs - x0, 0, 1)[..., None]
    fy = np.clip(ys - y0, 0, 1)[..., None]
    a, b = img[y0, x0], img[y0, x0 + 1]
    c, d = img[y0 + 1, x0], img[y0 + 1, x0 + 1]
    return (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy


class Scene:
    def __init__(self, path, focus_y=0.5):
        src = Image.open(path).convert("RGB")
        self.src_size = src.size
        # обрізка під 4:3 (для фото кота лишаємо нижню частину з мискою)
        k = 4 / 3
        if src.width / src.height > k:
            nw = int(src.height * k)
            x0 = (src.width - nw) // 2
            box = (x0, 0, x0 + nw, src.height)
        else:
            nh = int(src.width / k)
            y0 = int((src.height - nh) * focus_y)
            box = (0, y0, src.width, y0 + nh)
        self.box = box
        self.base = src.crop(box).resize((BW, BH), Image.LANCZOS)
        self.arr = np.asarray(self.base).astype(np.float32)
        a = self.arr
        r, g, b = a[..., 0], a[..., 1], a[..., 2]
        # трава / листя: зеленого більше, ніж червоного
        gm = np.clip((g - r + 6) / 26.0, 0, 1) * np.clip((g - b - 4) / 30.0, 0, 1)
        gm = np.asarray(Image.fromarray((gm * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(2.5)),
                        np.float32) / 255.0
        yy = (np.arange(BH, dtype=np.float32) / BH)[:, None]
        self.amp = (0.8 + 5.5 * yy ** 2) * gm
        self.xx, self.yy = np.meshgrid(np.arange(BW, dtype=np.float32), np.arange(BH, dtype=np.float32))
        # світло: яскраві місця трохи «дихають»
        lum = 0.299 * r + 0.587 * g + 0.114 * b
        br = np.clip((lum - 205) / 50.0, 0, 1)
        br = Image.fromarray((br * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(14))
        self.glow = (np.asarray(br, np.float32) / 255.0)[..., None] * np.array([255, 214, 150], np.float32)
        self.cat = None
        self.rows = slice(int(BH * 0.10), BH)

    def enable_cat(self):
        """Дихання: лише для фото кота з відомим контуром."""
        sx = BW / (self.box[2] - self.box[0])
        sy = BH / (self.box[3] - self.box[1])
        pts = [((x - self.box[0]) * sx, (y - self.box[1]) * sy) for x, y in CAT_POLY]
        m = Image.new("L", (BW, BH), 0)
        ImageDraw.Draw(m).polygon(pts, fill=255)
        m = np.asarray(m.filter(ImageFilter.GaussianBlur(16)), np.float32) / 255.0
        gm_inv = 1.0 - np.clip(self.amp / (0.8 + 5.5), 0, 1) * 0.0
        self.cat = m
        ys = [p[1] for p in pts]
        self.cat_top, self.cat_bot = min(ys), max(ys)

    def frame(self, t):
        """Одне «живе» зображення робочого розміру."""
        rs = self.rows
        xx, yy = self.xx[rs], self.yy[rs]
        amp = self.amp[rs]
        sway = (np.sin(2 * math.pi * 0.55 * t + xx * 0.011 + yy * 0.004)
                + 0.55 * np.sin(2 * math.pi * 1.15 * t + xx * 0.029 - yy * 0.011)
                + 0.25 * np.sin(2 * math.pi * 2.1 * t + xx * 0.06))
        xs, ys = xx + amp * sway, yy.copy()
        if self.cat is not None:
            e = 0.0075 * (0.5 - 0.5 * math.cos(2 * math.pi * t / 3.1))
            s = 1.0 + e
            ys = ys + self.cat[rs] * ((self.cat_bot - (self.cat_bot - yy) / s) - yy)
        out = self.arr.copy()
        out[rs] = bilinear(self.arr, xs, ys)
        pulse = 0.12 + 0.07 * math.sin(2 * math.pi * t / 2.7) + 0.03 * math.sin(2 * math.pi * t / 0.9)
        out += self.glow * pulse
        out *= 1.0 + 0.012 * math.sin(2 * math.pi * t / 4.3 + 0.7)
        return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))

    def camera(self, im, t, total):
        z = 1.0 + 0.09 * smooth(t / total) * 0.9 + 0.012 * (t / total)
        cw, ch = 1120 / z, 840 / z
        cx = BW / 2 + 9 * math.sin(2 * math.pi * t / 5.6) + 3.2 * math.sin(2 * math.pi * t / 1.7 + 1.0) - 14 * (t / total)
        cy = BH / 2 + 6 * math.sin(2 * math.pi * t / 4.4 + 0.6) + 2.4 * math.sin(2 * math.pi * t / 1.3) - 5 * (t / total)
        x0 = clamp(cx - cw / 2, 0, BW - cw)
        y0 = clamp(cy - ch / 2, 0, BH - ch)
        return im.resize((W, H), Image.BICUBIC, box=(x0, y0, x0 + cw, y0 + ch))


# ------------------------------------------------------------------ пилинки в контровому світлі
class Motes:
    def __init__(self, n=46, seed=5):
        r = random.Random(seed)
        self.p = [dict(x=r.uniform(0, W), y=r.uniform(0, H), d=r.uniform(0.25, 1.0), ph=r.uniform(0, 6.3),
                       tw=r.uniform(0.4, 1.3)) for _ in range(n)]

    def layer(self, t):
        far = Image.new("RGBA", (W * 2, H * 2), (0, 0, 0, 0))
        near = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        df, dn = ImageDraw.Draw(far), ImageDraw.Draw(near)
        for m in self.p:
            d = m["d"]
            x = (m["x"] + (3 + 7 * d) * t + 8 * d * math.sin(t * 0.8 + m["ph"])) % (W + 20) - 10
            y = (m["y"] - (4 + 9 * d) * t + 5 * math.sin(t * 0.6 + m["ph"] * 2)) % (H + 20) - 10
            a = int((28 + 100 * d) * (0.55 + 0.45 * math.sin(t * m["tw"] * 2 + m["ph"])))
            rad = 0.7 + 2.3 * d
            if d > 0.78:
                dn.ellipse((x - rad * 1.6, y - rad * 1.6, x + rad * 1.6, y + rad * 1.6), fill=(255, 238, 205, a // 2))
            else:
                df.ellipse((x * 2 - rad * 2, y * 2 - rad * 2, x * 2 + rad * 2, y * 2 + rad * 2), fill=(255, 240, 215, a))
        far = far.resize((W, H), Image.LANCZOS)
        near = near.filter(ImageFilter.GaussianBlur(1.6))
        far.alpha_composite(near)
        return far


# ------------------------------------------------------------------ текст
def text_layer(text, kind, size, tracking=0.0, alpha_shadow=0.6):
    f = pick_font(kind, size)
    d0 = ImageDraw.Draw(Image.new("L", (4, 4)))
    if tracking:
        widths = [d0.textlength(c, font=f) for c in text]
        total = sum(widths) + tracking * (len(text) - 1)
    else:
        total = d0.textlength(text, font=f)
    asc, desc = f.getmetrics()
    pad = 16
    w, h = int(total) + pad * 2, asc + desc + pad * 2

    def paint(fill, mask_mode):
        im = Image.new("L" if mask_mode else "RGBA", (w, h), 0 if mask_mode else (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        if tracking:
            x = pad
            for c, wd in zip(text, widths):
                d.text((x, pad), c, font=f, fill=fill)
                x += wd + tracking
        else:
            d.text((pad, pad), text, font=f, fill=fill)
        return im

    mask = paint(255, True)
    sh = mask.filter(ImageFilter.GaussianBlur(4)).point(lambda v: int(v * alpha_shadow))
    lay = Image.new("RGBA", (w, h), (10, 4, 0, 0))
    lay.putalpha(sh)
    top = Image.new("RGBA", (w, h), (255, 255, 255, 0))
    top.putalpha(mask)
    lay.alpha_composite(top)
    return lay, pad


def put(img, lay_pad, x, y, alpha=1.0, dy=0.0, anchor="l"):
    lay, pad = lay_pad
    if alpha <= 0:
        return
    a = lay.getchannel("A").point(lambda v: int(v * clamp(alpha)))
    l2 = lay.copy()
    l2.putalpha(a)
    px = int(x - pad - (lay.width - 2 * pad) / 2) if anchor == "c" else int(x - pad)
    img.alpha_composite(l2, (max(0, px), max(0, int(y - pad + dy)))) if px >= 0 and y - pad + dy >= 0 else \
        img.paste(l2, (px, int(y - pad + dy)), l2)


# ------------------------------------------------------------------ звук
def bell(sig, t0, f, dur=2.2, vol=0.2):
    i0, n = int(t0 * SR), int(dur * SR)
    t = np.arange(n) / SR
    s = (np.sin(2 * np.pi * f * t) * np.exp(-2.4 * t) + 0.32 * np.sin(2 * np.pi * f * 2.76 * t) * np.exp(-4.5 * t)
         + 0.12 * np.sin(2 * np.pi * f * 5.4 * t) * np.exp(-8 * t)) * np.minimum(1, t * 600) * vol
    j = min(len(sig), i0 + n)
    sig[i0:j] += s[:j - i0]


def chirp(sig, t0, f0, f1, dur=0.11, vol=0.06):
    i0, n = int(t0 * SR), int(dur * SR)
    tt = np.linspace(0, 1, n, endpoint=False)
    f = f0 + (f1 - f0) * tt ** 0.8
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * tt) ** 1.5 * vol
    j = min(len(sig), i0 + n)
    sig[i0:j] += s[:j - i0]


def meow(sig, t0, dur=0.85, vol=0.4):
    n = int(dur * SR)
    tt = np.linspace(0, 1, n, endpoint=False)
    f0 = 330 + 470 * np.sin(np.pi * tt ** 0.7) ** 1.1 - 80 * tt
    ph = 2 * np.pi * np.cumsum(f0) / SR
    f1 = 330 + 500 * np.sin(np.pi * tt)
    f2 = 2400 - 1200 * np.sin(np.pi * tt)
    out = np.zeros(n)
    for h in range(1, 26):
        fh = f0 * h
        g = np.exp(-((fh - f1) / 260) ** 2) + 0.7 * np.exp(-((fh - f2) / 480) ** 2) + 0.03
        out += g / h ** 0.8 * np.sin(h * ph)
    out += np.random.RandomState(3).randn(n) * 0.015
    out *= np.minimum(1, tt * dur / 0.08) * np.minimum(1, (1 - tt) * dur / 0.22)
    out *= vol / np.max(np.abs(out))
    i0 = int(t0 * SR)
    j = min(len(sig), i0 + n)
    sig[i0:j] += out[:j - i0]


def wind(n, vol=0.07, seed=9):
    rng = np.random.RandomState(seed)
    spec = np.fft.rfft(rng.standard_normal(n))
    fr = np.fft.rfftfreq(n, 1 / SR)
    spec *= 1 / (1 + (fr / 380) ** 3)
    w = np.fft.irfft(spec, n)
    w /= np.max(np.abs(w))
    t = np.arange(n) / SR
    return w * vol * (0.55 + 0.45 * np.sin(2 * np.pi * 0.21 * t + 1.0))


def write_wav(sig, path):
    n = len(sig)
    f = int(0.25 * SR)
    sig = sig.copy()
    sig[:f] *= np.linspace(0, 1, f)
    sig[-f:] *= np.linspace(1, 0, f)
    sig = sig / max(1.0, np.max(np.abs(sig)) / 0.88)
    st = np.stack([sig, sig * 0.985], 1)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((st * 32767).astype("<i2").tobytes())


# ------------------------------------------------------------------ відео
def vignette():
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    r = ((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2
    v = 1 - 0.20 * np.clip(r, 0, 1.6)
    v *= 1 - 0.22 * np.clip((yy / H - 0.62) / 0.38, 0, 1) ** 1.4      # м'яке затемнення знизу під підписи
    return v[..., None]


def finish(img, rng, fade, vig):
    a = np.asarray(img.convert("RGB"), np.float32) * vig
    a += rng.normal(0, 1.8, (H, W, 1)).astype(np.float32)
    a *= 1.0 - clamp(fade)
    return np.clip(a, 0, 255).astype(np.uint8).tobytes()


class Encoder:
    def __init__(self, ffmpeg, wav, mpg, mp4=None):
        base = [ffmpeg, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
                "-r", str(FPS), "-i", "-", "-i", wav, "-map", "0:v", "-map", "1:a"]
        cmds = [base + ["-c:v", "mpeg1video", "-b:v", "3200k", "-maxrate", "3800k", "-bufsize", "2000k", "-g", "12",
                        "-pix_fmt", "yuv420p", "-c:a", "mp2", "-b:a", "192k", "-ar", "44100", "-ac", "2",
                        "-shortest", "-f", "mpeg", mpg]]
        if mp4:
            cmds.append(base + ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "19", "-c:a", "aac",
                                "-b:a", "160k", "-shortest", mp4])
        self.p = [subprocess.Popen(c, stdin=subprocess.PIPE) for c in cmds]

    def write(self, raw):
        for p in self.p:
            p.stdin.write(raw)

    def close(self):
        for p in self.p:
            p.stdin.close()
            if p.wait() != 0:
                raise RuntimeError("ffmpeg завершився з помилкою")


def build_intro(img_path, out_dir, ffmpeg=None, preview=False, progress=None, studio="Scratch Studio",
                city="Жека Сіті", cat=None):
    """Повертає шляхи до Logo.mpg і GTAtitles.mpg."""
    ffmpeg = ffmpeg or find_ffmpeg()
    os.makedirs(out_dir, exist_ok=True)
    if cat is None:
        cat = os.path.basename(img_path).lower() == CAT_PHOTO_NAME
    scene = Scene(img_path, focus_y=0.75 if cat else 0.5)
    if cat:
        scene.enable_cat()
    rng = np.random.RandomState(21)
    vig = vignette()
    tmp = os.path.join(out_dir, "_tmp")
    os.makedirs(tmp, exist_ok=True)
    say = progress or (lambda f, s: None)

    # ---------------- Logo.mpg: «Scratch Studio» на приглушеному фото
    T = 3.4
    sig = np.zeros(int(T * SR))
    tt = np.arange(len(sig)) / SR
    sig += wind(len(sig), 0.05) + 0.05 * np.sin(2 * np.pi * (98 + 14 * tt) * tt) * np.clip(tt / 1.2, 0, 1)
    bell(sig, 0.65, 659.25, 2.4, 0.16)
    bell(sig, 0.8, 987.77, 2.0, 0.08)
    write_wav(sig, os.path.join(tmp, "logo.wav"))
    word = text_layer(studio.upper(), "semi", 34, tracking=9)
    cap = text_layer(city.upper(), "med", 12, tracking=5, alpha_shadow=0.5)
    enc = Encoder(ffmpeg, os.path.join(tmp, "logo.wav"), os.path.join(out_dir, "Logo.mpg"))
    still = scene.frame(0.0)
    n = int(T * FPS)
    for i in range(n):
        t = i / FPS
        bg = scene.camera(still, t * 0.5, T).filter(ImageFilter.GaussianBlur(9)).convert("RGBA")
        bg = Image.blend(bg, Image.new("RGBA", (W, H), (8, 4, 2, 255)), 0.62)
        a = smooth((t - 0.2) / 0.9) * (1 - smooth((t - 2.75) / 0.6))
        put(bg, word, W / 2, 212, a, dy=(1 - smooth((t - 0.2) / 0.9)) * 6, anchor="c")
        ln = int(150 * smooth((t - 0.5) / 0.9))
        if ln > 1:
            d = ImageDraw.Draw(bg)
            d.line((W / 2 - ln / 2, 276, W / 2 + ln / 2, 276), fill=(255, 255, 255, int(200 * a)), width=2)
        put(bg, cap, W / 2, 290, a * smooth((t - 0.9) / 0.7), anchor="c")
        enc.write(finish(bg, rng, 0, vig))
        say(0.12 * i / n, "Заставка…")
    enc.close()

    # ---------------- GTAtitles.mpg: «Scratch Studio Started» — фото оживає
    T = 7.4
    sig = np.zeros(int(T * SR))
    sig += wind(len(sig), 0.07)
    for t0, f0, f1 in ((1.15, 3600, 4300), (1.3, 3900, 3300), (1.44, 4200, 4700), (4.7, 3500, 4100),
                       (4.85, 3900, 3400), (6.1, 4000, 4600)):
        chirp(sig, t0, f0, f1)
    bell(sig, 0.9, 587.33, 2.6, 0.2)
    bell(sig, 1.05, 880.0, 2.2, 0.1)
    meow(sig, 3.55, 0.85, 0.42)
    bell(sig, 5.9, 440.0, 1.8, 0.12)
    write_wav(sig, os.path.join(tmp, "titles.wav"))
    title = text_layer(studio + " Started", "semi", 31)
    cap = text_layer(city.upper(), "med", 12, tracking=5, alpha_shadow=0.55)
    sub = text_layer("Йдемо зі мною", "med", 23, alpha_shadow=0.75)
    motes = Motes()
    mp4 = os.path.join(out_dir, "preview_Scratch_Studio_intro.mp4") if preview else None
    enc = Encoder(ffmpeg, os.path.join(tmp, "titles.wav"), os.path.join(out_dir, "GTAtitles.mpg"), mp4)
    n = int(T * FPS)
    for i in range(n):
        t = i / FPS
        img = scene.camera(scene.frame(t), t, T).convert("RGBA")
        img.alpha_composite(motes.layer(t))
        out_a = 1 - smooth((t - 6.2) / 0.5)
        ta = smooth((t - 0.9) / 0.9) * out_a
        put(img, title, 44, 338, ta, dy=(1 - smooth((t - 0.9) / 0.9)) * 9)
        ln = int(230 * smooth((t - 0.75) / 1.0))
        if ln > 1:
            ImageDraw.Draw(img).line((46, 384, 46 + ln, 384), fill=(255, 255, 255, int(215 * out_a)), width=2)
        put(img, cap, 46, 394, smooth((t - 1.4) / 0.8) * out_a)
        put(img, sub, W / 2, 430, smooth((t - 3.3) / 0.45) * out_a, anchor="c")
        enc.write(finish(img, rng, smooth((t - 6.55) / 0.85) + (1 - smooth(t / 0.7)), vig))
        say(0.12 + 0.88 * i / n, "Оживляю фото…")
    enc.close()
    shutil.rmtree(tmp, ignore_errors=True)
    say(1.0, "Готово")
    return os.path.join(out_dir, "Logo.mpg"), os.path.join(out_dir, "GTAtitles.mpg")


if __name__ == "__main__":
    import sys
    build_intro(sys.argv[1], sys.argv[2], preview="--preview" in sys.argv,
                progress=lambda f, s: print(f"{int(f * 100):3d}%  {s}", flush=True) if int(f * 100) % 10 == 0 else None)
