# -*- coding: utf-8 -*-
"""
zheka_gamefm.py — музика в РІДНОМУ радіо гри (станція «MP3 PLAYER», яка перемикається як звичайне FM).

Як це працює (офіційна можливість Vice City на ПК, див. support.rockstargames.com «Enabling the MP3 player in GTA:VC
for PC»): mp3-файли кладуться в папку MP3 у папці гри, і в грі з'являється станція «MP3 PLAYER» (остання праворуч).
Ми копіюємо туди твою музику й записуємо маніфест zheka_radio.json, щоб усе можна було прибрати.

Стокові станції (audio\\*.adf) за бажанням перейменовуються в *.adf.zheka_bak (нічого не видаляється).
Якщо гра закрилась за секунди після запуску — трейнер сам повертає стокове радіо (safety_check).
"""
import json
import os
import shutil
import subprocess
import time

MANIFEST = "zheka_radio.json"
MP3_NAMES = ("MP3", "MP3 Folder")          # назви папки, які згадують джерела; якщо одна вже є — беремо наявні
AUDIO_EXT = (".mp3", ".wav", ".wma", ".m4a", ".aac", ".ogg", ".flac")
TR = dict(zip("абвгґдеєжзиіїйклмнопрстуфхцчшщьюя", ["a", "b", "v", "h", "g", "d", "e", "ye", "zh", "z", "y", "i", "yi", "y",
                                                  "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "f", "kh", "ts", "ch",
                                                  "sh", "shch", "", "yu", "ya"]))
TR.update({"ё": "e", "ы": "y", "э": "e", "ъ": ""})


def ascii_name(stem):
    out = []
    for ch in stem.lower():
        if ch in TR:
            out.append(TR[ch])
        elif ch.isascii() and (ch.isalnum() or ch in " -_()"):
            out.append(ch)
        else:
            out.append("_")
    s = "".join(out).strip(" _.") or "track"
    return s[:40]


def collect_music(folder):
    """Усі аудіофайли папки та її підпапок (порядок стабільний)."""
    found = []
    if folder and os.path.isdir(folder):
        for root, dirs, files in os.walk(folder):
            dirs.sort(key=str.lower)
            for n in sorted(files, key=str.lower):
                if n.lower().endswith(AUDIO_EXT):
                    found.append(os.path.join(root, n))
    return found


def _ci_dir(base, name):
    try:
        for n in os.listdir(base):
            if n.lower() == name.lower() and os.path.isdir(os.path.join(base, n)):
                return os.path.join(base, n)
    except OSError:
        pass
    return ""


def target_dirs(game_dir):
    """Куди класти mp3: наявні папки MP3 / MP3 Folder / audio\\MP3; якщо жодної немає — створюємо MP3 і MP3 Folder."""
    have = [p for p in (_ci_dir(game_dir, n) for n in MP3_NAMES) if p]
    a = _ci_dir(game_dir, "audio")
    if a:
        p = _ci_dir(a, "mp3")
        if p:
            have.append(p)
    if have:
        return have, []
    return [os.path.join(game_dir, n) for n in MP3_NAMES], [os.path.join(game_dir, n) for n in MP3_NAMES]


def _convert(src, dst, ffmpeg):
    r = subprocess.run([ffmpeg, "-y", "-v", "error", "-i", src, "-vn", "-c:a", "libmp3lame", "-b:a", "192k", dst],
                       capture_output=True, timeout=600)
    return r.returncode == 0 and os.path.exists(dst) and os.path.getsize(dst) > 1000


def _read(game_dir):
    try:
        with open(os.path.join(game_dir, MANIFEST), "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(game_dir, d):
    p = os.path.join(game_dir, MANIFEST)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def stock_files(game_dir):
    a = _ci_dir(game_dir, "audio")
    if not a:
        return []
    return sorted(os.path.join(a, n) for n in os.listdir(a)
                  if n.lower().endswith(".adf") and os.path.isfile(os.path.join(a, n)))


def status(game_dir):
    d = _read(game_dir)
    return {"tracks": len(d.get("files", [])), "stock_removed": len(d.get("stock", [])),
            "stock_present": len(stock_files(game_dir))}


def install(game_dir, music_dir, remove_stock=True, ffmpeg=None, log=None):
    """Копіює музику в MP3-папку гри. Повертає список рядків-звітів. Помилка = ValueError, гру не чіпано."""
    log = log or (lambda s: None)
    if not game_dir or not os.path.isdir(game_dir):
        raise ValueError("Спочатку обери папку гри.")
    src = collect_music(music_dir)
    if not src:
        raise ValueError("У папці з музикою немає аудіо (mp3, wav, wma, m4a, aac, ogg, flac).")
    prior = _read(game_dir).get("stock", [])
    uninstall(game_dir, restore=False)                           # чисто: прибираємо власні старі файли
    if prior and not remove_stock:
        restore_stock(game_dir)
        prior = []
    dirs, created = target_dirs(game_dir)
    report, made, skipped = [], [], []
    plan = []                                                    # (джерело, ім'я mp3)
    used = set()
    for i, p in enumerate(src, 1):
        stem = ascii_name(os.path.splitext(os.path.basename(p))[0])
        name = f"{i:03d}_{stem}.mp3"
        plan.append((p, name))
        used.add(name)
    files_done = []
    try:
        for d in dirs:
            if not os.path.isdir(d):
                os.makedirs(d)
        first = dirs[0]
        for i, (p, name) in enumerate(plan, 1):
            log(f"Копіюю {i}/{len(plan)}: {name}")
            dst = os.path.join(first, name)
            if p.lower().endswith(".mp3"):
                shutil.copy2(p, dst)
            else:
                if not ffmpeg:
                    skipped.append(os.path.basename(p))
                    continue
                if not _convert(p, dst, ffmpeg):
                    skipped.append(os.path.basename(p))
                    if os.path.exists(dst):
                        os.remove(dst)
                    continue
            files_done.append(name)
        if not files_done:
            raise ValueError("Жодного файлу не вдалося підготувати (для не-mp3 потрібен ffmpeg: pip install imageio-ffmpeg).")
        for d in dirs[1:]:
            for name in files_done:
                shutil.copy2(os.path.join(first, name), os.path.join(d, name))
    except (OSError, ValueError, subprocess.SubprocessError) as e:
        for d in dirs:
            for name in files_done:
                try:
                    os.remove(os.path.join(d, name))
                except OSError:
                    pass
        for d in created:
            try:
                os.rmdir(d)
            except OSError:
                pass
        raise ValueError("Радіо не поставлено, гру не змінено: " + str(e))
    stock = list(prior)
    if remove_stock:
        for p in stock_files(game_dir):
            try:
                os.replace(p, p + ".zheka_bak")
                stock.append(os.path.basename(p))
            except OSError as e:
                report.append(f"Не вдалося сховати {os.path.basename(p)}: {e}")
    _write(game_dir, {"dirs": dirs, "created": created, "files": files_done, "stock": stock,
                      "t_installed": time.time(), "verified": False})
    report.append(f"Радіо: {len(files_done)} пісень у станції «MP3 PLAYER» (Налаштування гри -> Звук -> остання станція).")
    report.append("Папки: " + "; ".join(os.path.relpath(d, game_dir) for d in dirs))
    if stock:
        report.append(f"Стокові станції сховано: {len(stock)} (audio\\*.adf.zheka_bak). «Повернути радіо» повертає все.")
    elif remove_stock:
        report.append("Стокові станції (audio\\*.adf) не знайдено — нічого ховати.")
    if skipped:
        report.append("Пропущено (потрібен ffmpeg): " + ", ".join(skipped[:6]) + ("…" if len(skipped) > 6 else ""))
    return report


def restore_stock(game_dir):
    n = 0
    a = _ci_dir(game_dir, "audio")
    if a:
        for name in os.listdir(a):
            if name.lower().endswith(".adf.zheka_bak"):
                dst = os.path.join(a, name[:-len(".zheka_bak")])
                if not os.path.exists(dst):
                    os.replace(os.path.join(a, name), dst)
                    n += 1
                else:
                    os.remove(os.path.join(a, name))
    d = _read(game_dir)
    if d:
        d["stock"] = []
        _write(game_dir, d)
    return n


def uninstall(game_dir, restore=True):
    """Прибирає наші mp3 і (за бажанням) повертає стокові станції. Повертає (видалено mp3, повернено станцій)."""
    restore_stock_ = restore
    d = _read(game_dir)
    removed = 0
    for folder in d.get("dirs", []):
        for name in d.get("files", []):
            try:
                os.remove(os.path.join(folder, name))
                removed += 1
            except OSError:
                pass
    for folder in d.get("created", []):
        try:
            os.rmdir(folder)                                     # лише якщо порожня
        except OSError:
            pass
    back = restore_stock(game_dir) if restore_stock_ else 0
    if restore_stock_ or not d.get("stock"):
        try:
            os.remove(os.path.join(game_dir, MANIFEST))
        except OSError:
            pass
    else:
        d["files"], d["dirs"], d["created"] = [], [], []
        _write(game_dir, d)
    return removed, back


def safety_check(game_dir, alive_seconds, threshold=40):
    """Викликати, коли вікно гри зникло. Якщо стокове радіо сховане, а гра прожила менше threshold секунд
    (і радіо ще не підтверджене) — повертаємо стокове радіо. Повертає True, якщо повернули."""
    d = _read(game_dir)
    if not d or not d.get("stock") or d.get("verified"):
        return False
    if alive_seconds >= threshold:
        d["verified"] = True
        _write(game_dir, d)
        return False
    restore_stock(game_dir)
    d = _read(game_dir)
    d["verified"] = True
    _write(game_dir, d)
    return True


def mark_verified(game_dir):
    d = _read(game_dir)
    if d and not d.get("verified"):
        d["verified"] = True
        _write(game_dir, d)
