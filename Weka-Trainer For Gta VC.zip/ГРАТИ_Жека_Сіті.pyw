# Двічі клацни цей файл (або зроби ярлик на робочий стіл): стартує гра з меню «Жека Сіті».
import os, subprocess, sys
here = os.path.dirname(os.path.abspath(__file__))
subprocess.Popen([sys.executable, os.path.join(here, "zheka_cheat.py"), "--play"], cwd=here)
