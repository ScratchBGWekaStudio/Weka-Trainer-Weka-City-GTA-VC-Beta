# -*- coding: utf-8 -*-
"""
zheka_splash.py — колаж-заставка «Жека Сіті» з твоїх картинок + безпечна підміна текстури в .txd гри.

Колаж: квадратні плитки з картинок (коти, персонажі…) і плитка з написом, БЕЗ юридичного тексту.
Підміна: текстуру в splash*.txd переписують ТІЛЬКИ на місці — розміри, формат і структура файлу
лишаються тими самими. Якщо формат не розпізнано — файл не чіпається (ValueError).
Потрібно: Pillow, numpy.
"""
import math
import os
import struct

import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

IMG_EXT = (".jpg", ".jpeg", ".png", ".webp", ".bmp")
FONTS_BLACK = ["/usr/share/fonts/opentype/inter/Inter-Black.otf", r"C:\Windows\Fonts\seguibl.ttf",
               r"C:\Windows\Fonts\arialbd.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]
FONTS_MED = ["/usr/share/fonts/opentype/inter/Inter-SemiBold.otf", r"C:\Windows\Fonts\seguisb.ttf",
             r"C:\Windows\Fonts\segoeuib.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]


def _font(cands, size):
    for p in cands:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, int(size))
            except OSError:
                pass
    return ImageFont.load_default()


def list_pictures(folder):
    try:
        return sorted(os.path.join(folder, n) for n in os.listdir(folder) if n.lower().endswith(IMG_EXT))
    except OSError:
        return []


# ------------------------------------------------------------------ колаж
def _crop(img, w, h, zoom, fx, fy, flip=False):
    """Вирізає з картинки ділянку під плитку w x h; zoom>1 наближає, (fx, fy) — на що наводимо."""
    k = max(w / img.width, h / img.height) * zoom
    nw, nh = max(w, int(img.width * k) + 1), max(h, int(img.height * k) + 1)
    im = img.resize((nw, nh), Image.LANCZOS)
    x = int(clamp(fx * nw - w / 2, 0, nw - w))
    y = int(clamp(fy * nh - h / 2, 0, nh - h))
    im = im.crop((x, y, x + w, y + h))
    return ImageOps.mirror(im) if flip else im


def clamp(v, a, b):
    return max(a, min(b, v))


VARIANTS = [(1.0, 0.5, 0.42, False), (1.8, 0.5, 0.30, False), (1.5, 0.35, 0.62, True), (2.3, 0.62, 0.34, True),
            (1.3, 0.65, 0.55, False), (2.0, 0.40, 0.48, False)]
TINTS = [(0, 190, 230), (255, 110, 160), (255, 200, 60), (255, 130, 40), (60, 200, 170), (150, 110, 255)]


def build_collage(paths, size=(1024, 768), title=("ЖЕКА", "СІТІ"), studio="Scratch Studio"):
    imgs = []
    for p in paths:
        try:
            imgs.append(ImageOps.exif_transpose(Image.open(p)).convert("RGB"))
        except Exception:
            continue
    if not imgs:
        raise ValueError("Немає жодної картинки (JPG / PNG).")
    W, H = size
    S = 2                                           # малюємо вдвічі більше й стискаємо: гладкі краї
    cw, ch = W * S, H * S
    cv = Image.new("RGB", (cw, ch), (12, 16, 38))
    m, g = int(cw * 0.028), int(cw * 0.006)
    cols = [0.19, 0.20, 0.24, 0.20, 0.19]
    splits = [0.46, 0.53, 0.44, 0.47, 0.55]         # де ділиться кожна колонка (як у оригінальній мозаїці)
    avail_w, avail_h = cw - 2 * m - g * 4, ch - 2 * m - g
    x = m
    rects = []
    for c, frac in enumerate(cols):
        wcol = int(avail_w * frac)
        h1 = int(avail_h * splits[c])
        rects.append((x, m, wcol, h1))
        rects.append((x, m + h1 + g, wcol, avail_h - h1))
        x += wcol + g
    title_rect = rects[4] if title else None        # центральна колонка, верхня плитка = напис (або ще одна картинка)
    k = 0
    for r in rects:
        if r == title_rect:
            continue
        zoom, fx, fy, flip = VARIANTS[(k // len(imgs)) % len(VARIANTS)]
        tile = _crop(imgs[k % len(imgs)], r[2], r[3], zoom, fx, fy, flip)
        tint = Image.new("RGB", tile.size, TINTS[k % len(TINTS)])
        tile = Image.blend(ImageEnhance.Color(tile).enhance(1.12), tint, 0.10)
        cv.paste(tile, (r[0], r[1]))
        ImageDraw.Draw(cv).rectangle((r[0], r[1], r[0] + r[2] - 1, r[1] + r[3] - 1), outline=(8, 10, 24), width=S * 2)
        k += 1
    if title_rect is None:
        return cv.resize((W, H), Image.LANCZOS)
    # плитка з написом
    tx, ty, tw, th = title_rect
    grad = Image.linear_gradient("L").resize((tw, th))
    panel = Image.composite(Image.new("RGB", (tw, th), (222, 62, 120)), Image.new("RGB", (tw, th), (255, 168, 52)), grad)
    cv.paste(panel, (tx, ty))
    d = ImageDraw.Draw(cv)
    big = _font(FONTS_BLACK, 10)
    size_px = 10
    while size_px < 400:                            # підбираємо розмір, щоб слова вміщалися по ширині
        f = _font(FONTS_BLACK, size_px + 4)
        if max(d.textlength(t, font=f) for t in title) > tw * 0.88:
            break
        size_px += 4
    big = _font(FONTS_BLACK, size_px)
    lh = size_px * 1.02
    top = ty + th * 0.30
    for i, t in enumerate(title):
        cx, cy = tx + tw / 2, top + i * lh + lh / 2
        d.text((cx + S * 3, cy + S * 3), t, font=big, fill=(70, 20, 50), anchor="mm")
        d.text((cx, cy), t, font=big, fill=(255, 255, 255), anchor="mm", stroke_width=S * 2, stroke_fill=(70, 20, 50))
    sm = _font(FONTS_MED, size_px * 0.19)
    d.text((tx + tw / 2, ty + th * 0.13), studio.upper(), font=sm, fill=(255, 245, 235), anchor="mm")
    d.line((tx + tw * 0.2, ty + th * 0.2, tx + tw * 0.8, ty + th * 0.2), fill=(255, 245, 235), width=S * 2)
    d.line((tx + tw * 0.2, ty + th * 0.905, tx + tw * 0.8, ty + th * 0.905), fill=(255, 245, 235), width=S * 2)
    d.rectangle((tx, ty, tx + tw - 1, ty + th - 1), outline=(8, 10, 24), width=S * 2)
    return cv.resize((W, H), Image.LANCZOS)


# ------------------------------------------------------------------ TXD: розбір
class Tex:
    pass


def _u32(d, o):
    return struct.unpack_from("<I", d, o)[0]


def parse_txd(data):
    if len(data) < 28 or _u32(data, 0) != 0x16 or _u32(data, 4) + 12 != len(data):
        raise ValueError("Не схоже на TXD RenderWare.")
    if _u32(data, 12) != 1:
        raise ValueError("Незнайома структура TXD.")
    count = struct.unpack_from("<H", data, 24)[0]
    if not 1 <= count <= 8:
        raise ValueError(f"Незвична кількість текстур ({count}).")
    pos, texs = 12 + 12 + _u32(data, 16), []
    for _ in range(count):
        if pos + 24 > len(data) or _u32(data, pos) != 0x15:
            raise ValueError("Незнайомий блок текстури.")
        end = pos + 12 + _u32(data, pos + 4)
        if end > len(data) or _u32(data, pos + 12) != 1:
            raise ValueError("Пошкоджений блок текстури.")
        o = pos + 24
        t = Tex()
        if _u32(data, o) != 8:
            raise ValueError("Платформа текстури не D3D8 (інша версія гри?).")
        t.name = data[o + 8:o + 40].split(b"\0")[0].decode("ascii", "ignore")
        t.rf, t.alpha = _u32(data, o + 72), _u32(data, o + 76)
        t.w, t.h = struct.unpack_from("<HH", data, o + 80)
        t.depth, t.mips, t.rtype, t.comp = data[o + 84], data[o + 85], data[o + 86], data[o + 87]
        if not (4 <= t.w <= 4096 and 4 <= t.h <= 4096) or not 1 <= t.mips <= 13:
            raise ValueError("Незвичні розміри текстури.")
        p = o + 88
        t.pal = None
        if t.rf & 0x4000:
            raise ValueError("Палітра 4 біти не підтримується.")
        if t.rf & 0x2000:
            t.pal = p
            p += 1024
        t.levels = []
        for i in range(t.mips):
            if p + 4 > end:
                raise ValueError("Пошкоджені рівні текстури.")
            size = _u32(data, p)
            if p + 4 + size > end:
                raise ValueError("Пошкоджені рівні текстури.")
            t.levels.append((p + 4, size))
            p += 4 + size
        t.kind = _kind(t)
        texs.append(t)
        pos = end
    return texs


def _kind(t):
    w, h = t.w, t.h
    off, size = t.levels[0]
    if t.comp in (1, 3):
        blocks = ((w + 3) // 4) * ((h + 3) // 4)
        if size != blocks * (8 if t.comp == 1 else 16):
            raise ValueError("Розмір DXT не збігається.")
        return "dxt1" if t.comp == 1 else "dxt3"
    if t.comp not in (0,):
        raise ValueError(f"Стиснення {t.comp} не підтримується.")
    if t.pal is not None:
        if size != w * h:
            raise ValueError("Розмір палітрової текстури не збігається.")
        return "pal8"
    fmt = (t.rf >> 8) & 0xF
    if size == w * h * 4:
        return "bgra"
    if size == w * h * 2 and fmt in (1, 2, 3, 0xA):
        return {1: "a1555", 2: "r565", 3: "a4444", 0xA: "x555"}[fmt]
    raise ValueError("Формат пікселів не розпізнано.")


def lvl_dims(t, i):
    return max(4, t.w >> i) if t.comp in (1, 3) else max(1, t.w >> i), max(4, t.h >> i) if t.comp in (1, 3) else max(1, t.h >> i)


# ------------------------------------------------------------------ декодування (для визначення складання частин) і кодування
def decode(data, t, i=0):
    off, size = t.levels[i]
    w, h = lvl_dims(t, i)
    raw = data[off:off + size]
    k = t.kind
    if k == "bgra":
        a = np.frombuffer(raw, np.uint8).reshape(h, w, 4)
        return a[..., [2, 1, 0]].copy()
    if k == "pal8":
        pal = np.frombuffer(data, np.uint8, 1024, t.pal).reshape(256, 4)[:, :3]
        return pal[np.frombuffer(raw, np.uint8).reshape(h, w)]
    if k in ("a1555", "r565", "a4444", "x555"):
        v = np.frombuffer(raw, "<u2").reshape(h, w).astype(np.int32)
        if k == "r565":
            r, g, b = (v >> 11) & 31, (v >> 5) & 63, v & 31
            return np.stack([(r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)], -1).astype(np.uint8)
        if k == "a4444":
            r, g, b = (v >> 8) & 15, (v >> 4) & 15, v & 15
            return np.stack([r * 17, g * 17, b * 17], -1).astype(np.uint8)
        r, g, b = (v >> 10) & 31, (v >> 5) & 31, v & 31
        return np.stack([(r << 3) | (r >> 2), (g << 3) | (g >> 2), (b << 3) | (b >> 2)], -1).astype(np.uint8)
    stride = 8 if k == "dxt1" else 16
    n = (w // 4) * (h // 4)
    blk = np.frombuffer(raw, np.uint8, n * stride).reshape(n, stride)[:, -8:].astype(np.int32)
    c0, c1 = blk[:, 0] | (blk[:, 1] << 8), blk[:, 2] | (blk[:, 3] << 8)
    bits = blk[:, 4] | (blk[:, 5] << 8) | (blk[:, 6] << 16) | (blk[:, 7] << 24)

    def un(v):
        r, g, b = (v >> 11) & 31, (v >> 5) & 63, v & 31
        return np.stack([(r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)], -1)
    e0, e1 = un(c0), un(c1)
    pal = np.stack([e0, e1, (2 * e0 + e1) // 3, (e0 + 2 * e1) // 3], 1)
    idx = (bits[:, None] >> (2 * np.arange(16))) & 3
    px = pal[np.arange(n)[:, None], idx]
    return px.reshape(h // 4, w // 4, 4, 4, 3).transpose(0, 2, 1, 3, 4).reshape(h, w, 3).astype(np.uint8)


def _enc_dxt(rgb, kind):
    h, w, _ = rgb.shape
    b = rgb.reshape(h // 4, 4, w // 4, 4, 3).transpose(0, 2, 1, 3, 4).reshape(-1, 16, 3).astype(np.int32)
    mx, mn = b.max(1), b.min(1)
    inset = (mx - mn) >> 4
    hi, lo = mx - inset, mn + inset

    def p565(c):
        return ((c[:, 0] >> 3) << 11) | ((c[:, 1] >> 2) << 5) | (c[:, 2] >> 3)
    v0, v1 = p565(hi), p565(lo)
    sw = v0 < v1
    v0, v1 = np.where(sw, v1, v0), np.where(sw, v0, v1)

    def un(v):
        r, g, bl = (v >> 11) & 31, (v >> 5) & 63, v & 31
        return np.stack([(r << 3) | (r >> 2), (g << 2) | (g >> 4), (bl << 3) | (bl >> 2)], -1)
    e0, e1 = un(v0), un(v1)
    pal = np.stack([e0, e1, (2 * e0 + e1) // 3, (e0 + 2 * e1) // 3], 1)
    idx = ((b[:, :, None, :] - pal[:, None, :, :]) ** 2).sum(-1).argmin(-1).astype(np.uint32)
    bits = np.zeros(len(b), np.uint32)
    for j in range(16):
        bits |= idx[:, j] << np.uint32(2 * j)
    col = np.zeros(len(b), dtype=[("c0", "<u2"), ("c1", "<u2"), ("bits", "<u4")])
    col["c0"], col["c1"], col["bits"] = v0, v1, bits
    if kind == "dxt1":
        return col.tobytes()
    out = np.zeros((len(b), 16), np.uint8)
    out[:, :8] = 0xFF
    out[:, 8:] = np.frombuffer(col.tobytes(), np.uint8).reshape(-1, 8)
    return out.tobytes()


def encode(img, t, i, pal_img=None):
    w, h = lvl_dims(t, i)
    im = img.resize((w, h), Image.LANCZOS) if img.size != (w, h) else img
    rgb = np.asarray(im.convert("RGB"), np.uint8)
    k = t.kind
    if k == "bgra":
        out = np.full((h, w, 4), 255, np.uint8)
        out[..., :3] = rgb[..., ::-1]
        return out.tobytes()
    if k in ("a1555", "r565", "a4444", "x555"):
        r, g, b = (rgb[..., 0].astype(np.uint16), rgb[..., 1].astype(np.uint16), rgb[..., 2].astype(np.uint16))
        v = {"r565": ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3),
             "a1555": (1 << 15) | ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3),
             "x555": ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3),
             "a4444": (0xF << 12) | ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4)}[k]
        return v.astype("<u2").tobytes()
    if k == "pal8":
        return np.asarray(im.convert("RGB").quantize(palette=pal_img, dither=Image.Dither.FLOYDSTEINBERG), np.uint8).tobytes()
    return _enc_dxt(rgb, k)


# ------------------------------------------------------------------ підміна
def _arrange(parts):
    """Для двох частин вгадує, як вони складаються в екран, за плавністю шва. Повертає ('LR'|'RL'|'TB'|'BT', впевненість)."""
    a, b = [p.astype(np.float32) for p in parts]
    cands = {}

    def seam(x, y):
        n = min(len(x), len(y))
        return float(np.abs(np.resize(x, (n, 3)) - np.resize(y, (n, 3))).mean())
    if a.shape[0] == b.shape[0]:
        cands["LR"], cands["RL"] = seam(a[:, -1], b[:, 0]), seam(b[:, -1], a[:, 0])
    if a.shape[1] == b.shape[1]:
        cands["TB"], cands["BT"] = seam(a[-1], b[0]), seam(b[-1], a[0])
    if not cands:
        raise ValueError("Не вдалося скласти дві частини екрана.")
    order = sorted(cands.items(), key=lambda kv: kv[1])
    ratio = (order[1][1] + 1) / (order[0][1] + 1) if len(order) > 1 else 9.0
    return order[0][0], ratio


def patch_txd(data, collage):
    """Повертає нові байти TXD тієї ж довжини, де картинка замінена на колаж."""
    texs = parse_txd(data)
    out = bytearray(data)
    images = []
    if len(texs) == 1:
        t = texs[0]
        images.append(collage.resize((t.w, t.h), Image.LANCZOS))
    elif len(texs) == 2:
        parts = [decode(data, t) for t in texs]
        mode, _ = _arrange(parts)
        a, b = texs
        if mode in ("LR", "RL"):
            first, second = (a, b) if mode == "LR" else (b, a)
            full = collage.resize((first.w + second.w, first.h), Image.LANCZOS)
            pieces = {id(first): full.crop((0, 0, first.w, first.h)), id(second): full.crop((first.w, 0, first.w + second.w, first.h))}
        else:
            first, second = (a, b) if mode == "TB" else (b, a)
            full = collage.resize((first.w, first.h + second.h), Image.LANCZOS)
            pieces = {id(first): full.crop((0, 0, first.w, first.h)), id(second): full.crop((0, first.h, first.w, first.h + second.h))}
        images = [pieces[id(t)] for t in texs]
    else:
        raise ValueError("У файлі більше двох текстур: не підтримується.")
    for t, img in zip(texs, images):
        pal_img = None
        if t.kind == "pal8":
            q = img.convert("RGB").quantize(256, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
            pal_img = q
            pal = np.zeros((256, 4), np.uint8)
            pal[:, 3] = 255
            raw = np.array(q.getpalette()[:768], np.uint8).reshape(-1, 3)
            pal[:len(raw), :3] = raw
            out[t.pal:t.pal + 1024] = pal.tobytes()
        for i in range(t.mips):
            off, size = t.levels[i]
            block = encode(img, t, i, pal_img)
            if len(block) != size:
                raise ValueError("Розмір закодованого рівня не збігся.")
            out[off:off + size] = block
    res = bytes(out)
    check = parse_txd(res)                                # структура не змінилась
    if [(t.name, t.w, t.h, t.levels) for t in check] != [(t.name, t.w, t.h, t.levels) for t in texs] or len(res) != len(data):
        raise ValueError("Перевірка структури не пройшла.")
    return res


CAT_WORDS = ("cat", "kot", "кіт", "кот", "кіш", "kit")


def cat_pictures(folder, extra=()):
    """Картинки з котами: імена файлів зі словом cat/кіт/кот. Якщо таких немає — усі картинки папки."""
    allp = list_pictures(folder)
    cats = [p for p in allp if any(w in os.path.basename(p).lower() for w in CAT_WORDS)]
    out = cats or allp
    for e in extra:
        if e and os.path.exists(e) and e not in out:
            out.append(e)
    return out


def _scallop(size, color, r):
    """Прямокутник із хвилястим краєм, як листівка на заставці."""
    w, h = size
    im = Image.new("L", size, 0)
    d = ImageDraw.Draw(im)
    d.rectangle((r, r, w - r - 1, h - r - 1), fill=255)
    step = r * 2
    for x in range(r, w - r + 1, step):
        d.ellipse((x - r, 0, x + r, 2 * r), fill=255)
        d.ellipse((x - r, h - 2 * r - 1, x + r, h - 1), fill=255)
    for y in range(r, h - r + 1, step):
        d.ellipse((0, y - r, 2 * r, y + r), fill=255)
        d.ellipse((w - 2 * r - 1, y - r, w - 1, y + r), fill=255)
    return im


def build_postcard(paths, size=(1024, 768), top="З любов'ю з", words=("ЖЕКА", "СІТІ")):
    """Заставка-листівка «З любов'ю з ЖЕКА СІТІ»: літери заповнені картинками (коти), як у оригінальній заставці."""
    imgs = []
    for p in paths:
        try:
            imgs.append(ImageOps.exif_transpose(Image.open(p)).convert("RGB"))
        except Exception:
            continue
    if not imgs:
        raise ValueError("Немає жодної картинки (JPG / PNG).")
    W, H = size
    S = 2
    cw, ch = W * S, H * S
    cv = Image.new("RGB", (cw, ch), (14, 22, 60))
    mask = _scallop((int(cw * 0.94), int(ch * 0.86)), 255, int(cw * 0.011))
    grad = Image.linear_gradient("L").resize(mask.size)
    top_c, mid_c, bot_c = (255, 140, 30), (250, 196, 170), (255, 170, 20)
    card = Image.new("RGB", mask.size)
    cd = ImageDraw.Draw(card)
    for y in range(mask.size[1]):
        t = y / (mask.size[1] - 1)
        a, b, u = (top_c, mid_c, t * 2) if t < 0.5 else (mid_c, bot_c, (t - 0.5) * 2)
        cd.line([(0, y), (mask.size[0], y)], fill=tuple(int(a[i] + (b[i] - a[i]) * u) for i in range(3)))
    cx0, cy0 = (cw - mask.size[0]) // 2, int(ch * 0.07)
    cv.paste(card, (cx0, cy0), mask)
    d = ImageDraw.Draw(cv)
    f_top = _font(FONTS_MED, ch * 0.075)
    d.text((cx0 + cw * 0.07 + S * 3, cy0 + ch * 0.07 + S * 3), top, font=f_top, fill=(150, 90, 50))
    d.text((cx0 + cw * 0.07, cy0 + ch * 0.07), top, font=f_top, fill=(255, 255, 255), stroke_width=S, stroke_fill=(210, 140, 90))
    k = 0
    row_top = cy0 + ch * 0.17
    fit = []
    for word in words:                                  # однаковий розмір літер у всіх рядках
        size_px = 40
        while size_px < 900:
            f = _font(FONTS_BLACK, size_px + 8)
            wd = sum(d.textlength(c, font=f) for c in word)
            bb = d.textbbox((0, 0), word, font=f)
            if wd > cw * 0.70 or (bb[3] - bb[1]) > ch * 0.30:
                break
            size_px += 8
        fit.append(size_px)
    size_px = min(fit)
    f = _font(FONTS_BLACK, size_px)
    gb = d.textbbox((0, 0), "Ж", font=f)
    glyph_h = gb[3]
    for ri, word in enumerate(words):
        y = row_top + ri * (glyph_h + ch * 0.035) - gb[1] * 0.0
        widths = [d.textlength(c, font=f) for c in word]
        x = cx0 + (mask.size[0] - sum(widths)) / 2 + (cw * 0.03 if ri else -cw * 0.03)
        for ci, c in enumerate(word):
            lm = Image.new("L", (cw, ch), 0)
            ImageDraw.Draw(lm).text((x, y), c, font=f, fill=255)
            box = lm.getbbox()
            if box:
                bw, bh = box[2] - box[0], box[3] - box[1]
                zoom, fx, fy, flip = VARIANTS[(k // len(imgs)) % len(VARIANTS)]
                tile = _crop(imgs[k % len(imgs)], bw, bh, zoom, fx, fy, flip)
                full = Image.new("RGB", (cw, ch))
                full.paste(tile, (box[0], box[1]))
                out = Image.new("L", (cw, ch), 0)
                ImageDraw.Draw(out).text((x, y), c, font=f, fill=255, stroke_width=S * 6)
                cv.paste(Image.new("RGB", (cw, ch), (8, 6, 14)), (0, 0), out)
                cv.paste(full, (0, 0), lm)
                k += 1
            x += widths[ci]
    return cv.resize((W, H), Image.LANCZOS)
