# -*- coding: utf-8 -*-
"""
zheka_mainmenu.py — власне головне меню «Жека Сіті», яке лягає поверх рідного меню гри.
Зліва кнопки: ГРАТИ · НАЛАШТУВАННЯ · КЕРУВАННЯ (геймпад/мишка) · ЧИТИ · ВИЙТИ З ГРИ.
Справа вгорі назва «ЖЕКА СІТІ» в стилі GTA, під нею колаж з картинок трейнера.
Рідні пункти гри (Start / Options / Quit) натискаються клавішами стрілок і Enter.
"""
import os
import time
import tkinter as tk

from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk

import zheka_splash

BASE_W, BASE_H = 1024, 768
BUTTONS = ["play", "options", "exit"]
NATIVE = {"play": 0, "options": 1, "exit": 2}          # порядок рідного меню: Start, Options, Quit
BTN_X, BTN_Y, BTN_W, BTN_H, BTN_GAP = 36, 560, 340, 50, 6
FONTS = [r"C:\Windows\Fonts\seguibl.ttf", r"C:\Windows\Fonts\impact.ttf", r"C:\Windows\Fonts\arialbd.ttf",
         "/usr/share/fonts/opentype/inter/Inter-Black.otf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]


def _font(size):
    for p in FONTS:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, int(size))
            except OSError:
                pass
    return ImageFont.load_default()


def button_rects():
    return {b: (BTN_X, BTN_Y + i * (BTN_H + BTN_GAP), BTN_X + BTN_W, BTN_Y + i * (BTN_H + BTN_GAP) + BTN_H)
            for i, b in enumerate(BUTTONS)}


def gta_title(text="ЖЕКА СІТІ", width=520, height=150):
    """Напис у стилі GTA: важкі літери з нахилом, градієнт рожевий→помаранчевий, чорна обводка, тінь."""
    big = Image.new("RGBA", (width * 2, height * 2), (0, 0, 0, 0))
    f = _font(height * 1.35)
    d = ImageDraw.Draw(big)
    bb = d.textbbox((0, 0), text, font=f)
    k = min(1.0, (big.width - 60) / max(1, bb[2] - bb[0]))
    if k < 1:
        f = _font(height * 1.35 * k)
        bb = d.textbbox((0, 0), text, font=f)
    x, y = (big.width - (bb[2] - bb[0])) // 2 - bb[0], (big.height - (bb[3] - bb[1])) // 2 - bb[1]
    sh = Image.new("RGBA", big.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).text((x + 10, y + 12), text, font=f, fill=(20, 0, 40, 255), stroke_width=12, stroke_fill=(20, 0, 40, 255))
    mask = Image.new("L", big.size, 0)
    ImageDraw.Draw(mask).text((x, y), text, font=f, fill=255)
    grad = Image.new("RGBA", big.size)
    gd = ImageDraw.Draw(grad)
    for yy in range(big.height):
        t = yy / (big.height - 1)
        gd.line([(0, yy), (big.width, yy)], fill=(255, int(70 + 150 * (1 - t)), int(150 * t + 20), 255))
    glyph = Image.new("RGBA", big.size, (0, 0, 0, 0))
    glyph.paste(grad, (0, 0), mask)
    outline = Image.new("RGBA", big.size, (0, 0, 0, 0))
    ImageDraw.Draw(outline).text((x, y), text, font=f, fill=(0, 0, 0, 255), stroke_width=9, stroke_fill=(0, 0, 0, 255))
    out = Image.alpha_composite(Image.alpha_composite(sh, outline), glyph)
    out = out.transform(out.size, Image.AFFINE, (1, 0.18, -0.18 * out.height / 2, 0, 1, 0), Image.BICUBIC)
    return out.resize((width, height), Image.LANCZOS)


def render(labels, hover, collage, ctrl_label, confirm_exit=False):
    """Мінімальне меню: фон — картинки з котами, зліва внизу в кутку три прості написи, зверху маленький «ЖЕКА СІТІ»."""
    if collage is not None:
        im = ImageOps.fit(collage.convert("RGB"), (BASE_W, BASE_H), Image.LANCZOS)
    else:
        im = Image.new("RGB", (BASE_W, BASE_H), (24, 10, 48))
    shade = Image.new("L", (BASE_W, BASE_H), 0)                 # легке затемнення знизу зліва, щоб текст читався
    sd = ImageDraw.Draw(shade)
    for y in range(BASE_H):
        sd.line([(0, y), (BASE_W, y)], fill=int(150 * max(0.0, (y - BASE_H * 0.55) / (BASE_H * 0.45))))
    im = Image.composite(Image.new("RGB", (BASE_W, BASE_H), (10, 4, 24)), im, shade)
    d = ImageDraw.Draw(im)
    f_t = _font(40)
    d.text((34, 26), "ЖЕКА СІТІ", font=f_t, fill=(255, 255, 255), stroke_width=4, stroke_fill=(20, 6, 40))
    f = _font(32)
    for b, (x0, y0, x1, y1) in button_rects().items():
        on = hover == b
        txt = labels[b] if not (b == "exit" and confirm_exit) else "Точно? Тисни ще раз"
        col = (255, 176, 60) if on else (255, 255, 255)
        d.text((x0 + (22 if on else 0), (y0 + y1) // 2), ("› " if on else "") + txt, font=f, fill=col, anchor="lm",
               stroke_width=3, stroke_fill=(20, 6, 40))
    d.text((34, BASE_H - 30), "Версія Жека і Клео", font=_font(16), fill=(255, 225, 200), stroke_width=2,
           stroke_fill=(20, 6, 40))
    return im


LABELS = {"play": "Грати", "options": "Налаштування", "exit": "Вийти з гри"}


class MainMenu:
    def __init__(self, app, h):
        """h: словник допоміжних функцій з трейнера: user32, find_game_window, send_scan, tap, osd, show_cheats, collage"""
        self.app, self.h = app, h
        self.win, self.visible = None, False
        self.hover, self.native, self.exit_until = None, 0, 0.0
        self.photo = None
        self.collage = None
        self.started = False                      # після «Грати» меню вже не на головному екрані

    # --- стан
    def ctrl_mode(self):
        return self.app.settings.get("menu_ctrl", "game")

    def ctrl_label(self):
        return "КЕРУВАННЯ: " + ("ГЕЙМПАД" if self.ctrl_mode() == "game" else "МИШКА")

    def game_rect(self):
        u = self.h["user32"]
        hwnd = self.h["find_game_window"]()
        if not hwnd:
            return None
        import ctypes
        from ctypes import wintypes
        rc, pt = wintypes.RECT(), wintypes.POINT(0, 0)
        u.GetClientRect(hwnd, ctypes.byref(rc))
        u.ClientToScreen(hwnd, ctypes.byref(pt))
        return pt.x, pt.y, max(320, rc.right), max(240, rc.bottom)

    def score(self):
        """Наскільки екран гри схожий на колаж (рідне меню має колаж на фоні). None — не вдалося зняти екран."""
        r = self.game_rect()
        if not r:
            return None
        try:
            from PIL import ImageGrab
            import numpy as np
            if getattr(self, "bg", None) is None:
                self.bg = (self.h.get("bg") or self.h["collage"])()
            x, y, w, hh = r
            a = np.asarray(ImageGrab.grab(bbox=(x, y, x + w, y + hh), all_screens=True).convert("L").resize((64, 48)), float).ravel()
            b = np.asarray(self.bg.convert("L").resize((64, 48)), float).ravel()
            a, b = a - a.mean(), b - b.mean()
            sc = float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9))
        except Exception:
            return None
        try:
            with open(os.path.join(self.h.get("log_dir", "."), "zheka_detect.log"), "a", encoding="utf-8") as f:
                f.write(f"{time.strftime('%H:%M:%S')} збіг з колажем: {sc:.2f}\n")
        except OSError:
            pass
        return sc

    # --- показ / сховати
    def show(self):
        r = self.game_rect()
        if not r:
            self.h["osd"]("Гру не знайдено", "Спочатку запусти Vice City")
            return
        if self.collage is None:
            try:
                self.collage = self.h["collage"]()
            except Exception:
                self.collage = None
        x, y, w, hh = r
        if self.win is None:
            self.win = tk.Toplevel(self.app)
            self.win.overrideredirect(True)
            self.cv = tk.Canvas(self.win, highlightthickness=0, bd=0, bg="#120828")
            self.cv.pack(fill="both", expand=True)
            self.cv.bind("<Motion>", self.on_move)
            self.cv.bind("<Button-1>", self.on_click)
        self.win.geometry(f"{w}x{hh}+{x}+{y}")
        self.win.attributes("-topmost", True)
        self.win.deiconify()
        self.h["noactivate"](self.win)
        self.visible = True
        if not self.started:
            self.native = 0                           # меню гри при старті стоїть на першому пункті
        self.hover = "play"
        self.draw()
        if self.app.pad:                              # у меню геймпад керує курсором
            self.app.pad.cmd("set_mode", "pc")

    def hide(self):
        if self.win:
            self.win.withdraw()
        self.visible = False
        if self.app.pad:
            self.app.pad.cmd("set_mode", self.ctrl_mode())

    def toggle(self):
        self.hide() if self.visible else self.show()

    # --- малювання
    def draw(self):
        if not self.win:
            return
        w, hh = max(2, self.win.winfo_width()), max(2, self.win.winfo_height())
        if w < 50:
            w, hh = int(self.win.geometry().split("x")[0]), int(self.win.geometry().split("x")[1].split("+")[0])
        labels = dict(LABELS)
        im = render(labels, self.hover, self.collage, self.ctrl_label(), time.time() < self.exit_until)
        self.photo = ImageTk.PhotoImage(im.resize((w, hh), Image.LANCZOS))
        self.cv.delete("all")
        self.cv.create_image(0, 0, anchor="nw", image=self.photo)

    def hit(self, ex, ey):
        w, hh = max(1, self.cv.winfo_width()), max(1, self.cv.winfo_height())
        bx, by = ex * BASE_W / w, ey * BASE_H / hh
        for b, (x0, y0, x1, y1) in button_rects().items():
            if x0 <= bx <= x1 and y0 <= by <= y1:
                return b
        return None

    def on_move(self, e):
        b = self.hit(e.x, e.y)
        if b != self.hover and b:
            self.hover = b
            self.draw()

    def on_click(self, e):
        b = self.hit(e.x, e.y)
        if b:
            self.hover = b
            self.activate(b)

    # --- клавіші (стрілки й Enter, які перехопив KeyHook)
    def move(self, d):
        i = BUTTONS.index(self.hover) if self.hover in BUTTONS else 0
        self.hover = BUTTONS[(i + d) % len(BUTTONS)]
        self.draw()

    def enter(self):
        self.activate(self.hover)

    # --- дії
    def native_press(self, idx, enter=True):
        """Ставить курсор рідного меню на пункт idx і (за потреби) тисне Enter. Працює в окремому потоці."""
        import threading
        steps = (idx - self.native) % 3
        self.native = idx

        def run():
            tap = self.h["tap"]
            for _ in range(steps):
                tap(0x50, True)
                time.sleep(0.12)
            if enter:
                tap(0x1C, False)
        threading.Thread(target=run, daemon=True).start()

    def activate(self, b):
        if b == "play":
            self.hide()
            if not self.started:
                self.started = True
                self.app.after(150, lambda: self.native_press(NATIVE["play"]))
        elif b == "options":
            self.hide()
            if self.started:                          # серед гри «Налаштування» = рідна пауза (Esc)
                self.app.after(150, lambda: self.h["tap"](0x01, False))
            else:
                self.app.after(150, lambda: self.native_press(NATIVE["options"]))
        elif b == "controls":
            new = "pc" if self.ctrl_mode() == "game" else "game"
            self.app.settings["menu_ctrl"] = new
            self.h["save"](self.app.settings)
            self.draw()
        elif b == "cheats":
            self.hide()
            self.h["show_cheats"]()
        elif b == "exit":
            now = time.time()
            if now < self.exit_until:
                self.exit_until = 0
                hwnd = self.h["find_game_window"]()
                if hwnd:
                    self.h["user32"].PostMessageW(hwnd, 0x0010, 0, 0)       # WM_CLOSE
                self.hide()
            else:
                self.exit_until = now + 3
                self.draw()
                self.app.after(3100, self.draw)
