# -*- coding: utf-8 -*-
"""
Жека Чіц — USB-геймпад, режим комп'ютера (X) і радіо FM.

Працює через стандартний Windows (winmm + SendInput + MCI): ніяких додаткових програм і pip-пакетів.
Усі кнопки та клавіші можна «навчити» у вікні Налаштування -> Геймпад: схема за замовчуванням —
припущення для типових USB-геймпадів, де кнопки підписані 1, 2, 3, 4 (як на твоєму).
"""
import collections
import ctypes
import json
import math
import os
import random
import threading
import time

IS_WIN = os.name == "nt"

# ------------------------------------------------------------------ схема за замовчуванням
BTN_ORDER = ["1", "2", "3", "4", "L1", "L2", "R1", "R2", "SELECT", "START", "L3", "R3"]
# логічна кнопка -> номер у Windows (0 = кнопка «1» у joy.cpl). Типова розкладка USB-геймпадів у стилі PS2.
DEFAULT_MAP = {"1": 0, "2": 1, "3": 2, "4": 3, "L1": 4, "R1": 5, "L2": 6, "R2": 7,
               "SELECT": 8, "START": 9, "L3": 10, "R3": 11}
OLD_MAP = {"1": 0, "2": 1, "3": 2, "4": 3, "L2": 4, "R2": 5, "L1": 6, "R1": 7,
           "SELECT": 8, "START": 9, "L3": 10, "R3": 11}
AXIS_ORDER = ["x", "y", "z", "r", "u", "v"]
DEFAULT_AXES = {"lx": "x", "ly": "y", "rx": "z", "ry": "r"}


def K(scan, name, ext=False):
    return {"scan": scan, "ext": ext, "name": name}


def W(d):
    return {"wheel": d, "name": "Колесо ↑" if d > 0 else "Колесо ↓"}


# (id, назва, підказка, клавіша гри за замовчуванням)
ACTIONS = [
    ("enter", "Сісти / вийти з авто", "кнопка 1", K(0x1C, "Enter")),
    ("sprint", "Бігти швидше", "кнопка 2 і R1 (права «1» зверху), тримати", K(0x2A, "Shift лів.")),
    ("crouch", "Присісти", "кнопка 3", K(0x2E, "C")),
    ("mission", "Почати квест (авто / лікарня)", "кнопка 4", K(0x3A, "Caps Lock")),
    ("attack", "Битися / стріляти", "L2 R2 (тримати)", K(0x1D, "Ctrl лів.")),
    ("radio_off", "Вимкнути радіо", "L1 (ліва «1» зверху)", K(0x52, "Insert", True)),
    ("weapon_next", "Наступна зброя", "SELECT + 1", W(1)),
    ("weapon_prev", "Попередня зброя", "SELECT + 3", W(-1)),
    ("weapon_dpad_next", "Зброя: хрестовина ↑", "хрестовина ↑ (світиться ANALOG)", W(1)),
    ("weapon_dpad_prev", "Зброя: хрестовина ↓", "хрестовина ↓ (світиться ANALOG)", W(-1)),
    ("radio_next", "Радіо гри: наступна станція", "хрестовина →", K(0x52, "Insert", True)),
    ("radio_prev", "Радіо гри: попередня станція", "хрестовина ←", K(0x53, "Delete", True)),
    ("menu", "Меню", "START", K(0x01, "Esc")),
    ("up", "Вперед / газ", "ліва ручка ↑", K(0x48, "↑", True)),
    ("down", "Назад / гальмо", "ліва ручка ↓", K(0x50, "↓", True)),
    ("left", "Ліворуч", "ліва ручка ←", K(0x4B, "←", True)),
    ("right", "Праворуч", "ліва ручка →", K(0x4D, "→", True)),
]
DEFAULT_KEYS = {a[0]: a[3] for a in ACTIONS}

DEFAULTS = {
    "pad_on": True, "pad_map": dict(DEFAULT_MAP), "pad_axes": dict(DEFAULT_AXES),
    "pad_x": ["SELECT", "START"],                     # «кнопка X»: комбінація, що перемикає режим гра ↔ комп'ютер
    "pad_keys": {k: dict(v) for k, v in DEFAULT_KEYS.items()},
    "pad_look": 8, "pad_cursor": 10, "pad_dead": 22, "pad_invert": False,
    "pad_radio_native": True, "radio_dir": "", "radio_vol": 70, "radio_station": 0, "radio_game_only": True, "radio_live": True,
}

AUDIO_EXT = (".mp3", ".wav", ".wma", ".m4a", ".aac")

# ------------------------------------------------------------------ Windows API (окремі екземпляри DLL,
# щоб не чіпати типи аргументів, які вже налаштував основний файл)
if IS_WIN:
    from ctypes import wintypes
    u32 = ctypes.WinDLL("user32")
    mm = ctypes.WinDLL("winmm")

    class JOYINFOEX(ctypes.Structure):
        _fields_ = [(n, wintypes.DWORD) for n in (
            "dwSize", "dwFlags", "dwXpos", "dwYpos", "dwZpos", "dwRpos", "dwUpos", "dwVpos",
            "dwButtons", "dwButtonNumber", "dwPOV", "dwReserved1", "dwReserved2")]

    class JOYCAPSW(ctypes.Structure):
        _fields_ = ([("wMid", wintypes.WORD), ("wPid", wintypes.WORD), ("szPname", ctypes.c_wchar * 32)]
                    + [(n, wintypes.UINT) for n in (
                        "wXmin", "wXmax", "wYmin", "wYmax", "wZmin", "wZmax", "wNumButtons", "wPeriodMin",
                        "wPeriodMax", "wRmin", "wRmax", "wUmin", "wUmax", "wVmin", "wVmax", "wCaps",
                        "wMaxAxes", "wNumAxes", "wMaxButtons")]
                    + [("szRegKey", ctypes.c_wchar * 32), ("szOEMVxD", ctypes.c_wchar * 260)])

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]

    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t)]

    class _U(ctypes.Union):
        _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT)]

    class INPUT(ctypes.Structure):
        _fields_ = [("type", wintypes.DWORD), ("u", _U)]

    mm.joyGetPosEx.argtypes = [wintypes.UINT, ctypes.POINTER(JOYINFOEX)]
    mm.joyGetDevCapsW.argtypes = [ctypes.c_size_t, ctypes.POINTER(JOYCAPSW), wintypes.UINT]
    mm.mciSendStringW.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.UINT, ctypes.c_void_p]
    u32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
    u32.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
    u32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
    u32.MapVirtualKeyW.argtypes = [wintypes.UINT, wintypes.UINT]

    def _send(inp):
        u32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))

    def key_event(scan, ext, up):
        flags = 0x0008 | (0x0002 if up else 0) | (0x0001 if ext else 0)   # SCANCODE | KEYUP | EXTENDED
        i = INPUT()
        i.type = 1
        i.u.ki = KEYBDINPUT(0, scan, flags, 0, 0)
        _send(i)

    M_MOVE, M_LDOWN, M_LUP, M_RDOWN, M_RUP, M_MDOWN, M_MUP, M_WHEEL = 1, 2, 4, 8, 0x10, 0x20, 0x40, 0x800

    def mouse_event(flags, dx=0, dy=0, data=0):
        i = INPUT()
        i.type = 0
        i.u.mi = MOUSEINPUT(dx, dy, data & 0xFFFFFFFF, flags, 0, 0)
        _send(i)

    def cursor_move(dx, dy):
        pt = wintypes.POINT()
        u32.GetCursorPos(ctypes.byref(pt))
        vx, vy = u32.GetSystemMetrics(76), u32.GetSystemMetrics(77)
        vw, vh = u32.GetSystemMetrics(78) or 1920, u32.GetSystemMetrics(79) or 1080
        u32.SetCursorPos(int(min(max(pt.x + dx, vx), vx + vw - 1)), int(min(max(pt.y + dy, vy), vy + vh - 1)))

    def mci(cmd):
        buf = ctypes.create_unicode_buffer(300)
        err = mm.mciSendStringW(cmd, buf, 299, None)
        return err, buf.value
else:                                   # на інших системах модуль імпортується (для перевірок), але нічого не робить
    def key_event(scan, ext, up): pass
    def mouse_event(flags, dx=0, dy=0, data=0): pass
    def cursor_move(dx, dy): pass
    def mci(cmd): return 1, ""
    M_MOVE, M_LDOWN, M_LUP, M_RDOWN, M_RUP, M_MDOWN, M_MUP, M_WHEEL = 1, 2, 4, 8, 0x10, 0x20, 0x40, 0x800


# ------------------------------------------------------------------ геймпад (winmm)
def pov_dirs(pov):
    """Хрестовина: кути в сотих градуса (0 = вгору). -1 = не натиснуто."""
    if pov < 0:
        return set()
    d = set()
    if pov <= 4500 or pov >= 31500:
        d.add("up")
    if 4500 <= pov <= 13500:
        d.add("right")
    if 13500 <= pov <= 22500:
        d.add("down")
    if 22500 <= pov <= 31500:
        d.add("left")
    return d


class Joy:
    """Перший знайдений джойстик Windows. poll() -> dict або None."""

    def __init__(self):
        self.id, self.name, self.rng, self.t_scan = None, "", {}, 0.0

    def _read(self, i):
        info = JOYINFOEX()
        info.dwSize = ctypes.sizeof(JOYINFOEX)
        info.dwFlags = 0xFF                        # JOY_RETURNALL
        return info if mm.joyGetPosEx(i, ctypes.byref(info)) == 0 else None

    def _caps(self, i):
        self.name, self.rng = "USB-геймпад", {a: (0, 65535) for a in AXIS_ORDER}
        c = JOYCAPSW()
        if mm.joyGetDevCapsW(i, ctypes.byref(c), ctypes.sizeof(c)) == 0:
            self.name = c.szPname.strip() or self.name
            for a, lo, hi in (("x", c.wXmin, c.wXmax), ("y", c.wYmin, c.wYmax), ("z", c.wZmin, c.wZmax),
                              ("r", c.wRmin, c.wRmax), ("u", c.wUmin, c.wUmax), ("v", c.wVmin, c.wVmax)):
                if hi > lo:
                    self.rng[a] = (lo, hi)

    def poll(self):
        if not IS_WIN:
            return None
        info = self._read(self.id) if self.id is not None else None
        if info is None:
            self.id = None
            now = time.time()
            if now - self.t_scan < 1.0:            # шукаємо не частіше разу на секунду
                return None
            self.t_scan = now
            for i in range(16):
                info = self._read(i)
                if info is not None:
                    self.id = i
                    self._caps(i)
                    break
            else:
                return None
        axes = {}
        for a, raw in (("x", info.dwXpos), ("y", info.dwYpos), ("z", info.dwZpos),
                       ("r", info.dwRpos), ("u", info.dwUpos), ("v", info.dwVpos)):
            lo, hi = self.rng.get(a, (0, 65535))
            axes[a] = max(-1.0, min(1.0, (raw - lo) / float(hi - lo) * 2.0 - 1.0))
        pov = info.dwPOV
        pov = -1 if pov == 0xFFFFFFFF or pov > 36000 else int(pov)
        return {"buttons": int(info.dwButtons), "axes": axes, "pov": pov}


def curve(v, dz):
    """Мертва зона + м'який старт: мала відмашка = точно, повна = швидко."""
    a = abs(v)
    if a <= dz:
        return 0.0
    a = (a - dz) / (1.0 - dz)
    return math.copysign(a * a, v)


# ------------------------------------------------------------------ радіо FM
class Radio:
    """Станції = підпапки папки radio (у кожній свої пісні). Пісні просто в radio\\ = станція «Жека FM».
    Грає через MCI Windows: mp3, wav, wma, m4a, aac."""
    ALIAS = "zheka_fm"

    def __init__(self):
        self.stations = []                 # [(назва, [шляхи])]
        self.idx = 0                       # 0 = радіо вимкнене
        self.vol = 70
        self.order, self.pos = [], 0
        self.open_ = False
        self.suspended = False
        self.track = ""
        self.fails = 0
        self.dead = False                  # усі файли станції не відтворюються: не мучимо їх щосекунди

    def scan(self, folder):
        found = []
        if folder and os.path.isdir(folder):
            def tracks(d):
                try:
                    names = sorted(os.listdir(d), key=str.lower)
                except OSError:
                    return []
                return [os.path.join(d, n) for n in names
                        if n.lower().endswith(AUDIO_EXT) and os.path.isfile(os.path.join(d, n))]
            loose = tracks(folder)
            if loose:
                found.append(("Жека FM", loose))
            try:
                subs = sorted((n for n in os.listdir(folder) if os.path.isdir(os.path.join(folder, n))), key=str.lower)
            except OSError:
                subs = []
            for n in subs:
                t = tracks(os.path.join(folder, n))
                if t:
                    found.append((n, t))
        was = self.stations[self.idx - 1][0] if self.idx and self.idx <= len(self.stations) else None
        self.stations = found
        names = [s[0] for s in found]
        if self.idx > len(found):
            self.idx = 0
        elif was and was in names:
            self.idx = names.index(was) + 1
        return len(found), sum(len(s[1]) for s in found)

    # --- MCI
    def _close(self):
        if self.open_:
            mci("close " + self.ALIAS)
            self.open_ = False

    def _volume(self):
        if self.open_:
            mci(f"setaudio {self.ALIAS} volume to {int(max(0, min(100, self.vol)) * 10)}")

    def _play(self, path, live):
        self._close()
        kind = "waveaudio" if path.lower().endswith(".wav") else "mpegvideo"
        err, _ = mci(f'open "{path}" type {kind} alias {self.ALIAS}')
        if err:
            return False
        self.open_ = True
        mci(f"set {self.ALIAS} time format milliseconds")
        self._volume()
        if live:                                         # як справжній ефір: з'являємось посеред пісні
            e, length = mci(f"status {self.ALIAS} length")
            if not e and length.isdigit() and int(length) > 20000:
                mci(f"seek {self.ALIAS} to {random.randint(int(length) * 5 // 100, int(length) * 70 // 100)}")
        err, _ = mci(f"play {self.ALIAS}")
        if err:
            self._close()
            return False
        self.suspended = False
        self.track = os.path.splitext(os.path.basename(path))[0]
        return True

    def _start_station(self, live):
        name, files = self.stations[self.idx - 1]
        self.order = files[:]
        random.shuffle(self.order)
        self.pos, self.fails, self.dead = 0, 0, False
        self._advance(live, first=True)

    def _advance(self, live=False, first=False):
        """Наступна пісня; биті файли пропускаємо."""
        if not self.idx or not self.order:
            return
        for _ in range(len(self.order)):
            if not first:
                self.pos = (self.pos + 1) % len(self.order)
            first = False
            if self._play(self.order[self.pos], live):
                self.fails = 0
                return
            self.fails += 1
        self.track = "(файли не відтворюються)"
        self.dead = True

    def tune(self, idx, live=True):
        n = len(self.stations)
        self._close()
        self.track = ""
        if n == 0:
            self.idx = 0
            return "Радіо: у папці radio немає музики"
        self.idx = idx % (n + 1)
        if self.idx == 0:
            return "Радіо вимкнено"
        self._start_station(live)
        return f"FM {self.idx}/{n} · {self.stations[self.idx - 1][0]}"

    def step(self, d, live=True):
        return self.tune(self.idx + d, live)

    def set_volume(self, v):
        self.vol = max(0, min(100, int(v)))
        self._volume()

    def tick(self, active):
        """Раз на ~0.4 с: пауза, коли гра не активна, і перехід до наступної пісні."""
        if not self.idx or self.dead:
            return
        if not self.open_ and active:
            self._start_station(False)                   # стартові налаштування: радіо було ввімкнене
            return
        if not self.open_:
            return
        if not active and not self.suspended:
            mci("pause " + self.ALIAS)
            self.suspended = True
        elif active and self.suspended:
            mci("resume " + self.ALIAS)
            self.suspended = False
        if active and not self.suspended:
            err, mode = mci(f"status {self.ALIAS} mode")
            if not err and mode.strip().lower() == "stopped":
                self._advance(False)

    def label(self):
        if not self.idx:
            return "вимк"
        return f"{self.idx}/{len(self.stations)}"

    def stop(self):
        self._close()


# ------------------------------------------------------------------ майстер «Навчити геймпад»
class Wizard:
    """Крок за кроком дізнається, який номер у Windows має кожна кнопка і які осі — у ручок.
    Чиста логіка без Tk: feed(snap, now) викликається з вікна."""

    def __init__(self, steps, base_map=None):
        self.steps = steps
        self.base_map = dict(base_map or DEFAULT_MAP)
        self.i, self.done, self.note = 0, False, ""
        self.res = {"map": {}, "axes": {}, "x": None}
        self._reset()

    @staticmethod
    def full_steps():
        s = [{"kind": "axes", "keys": ("lx", "ly"), "text": "Крути ЛІВУ ручку по колу кілька разів"},
             {"kind": "axes", "keys": ("rx", "ry"), "text": "Крути ПРАВУ ручку по колу кілька разів"}]
        for n in BTN_ORDER:
            hint = {"L1": " — ЛІВА кнопка «1» зверху (вимкнути радіо)", "L2": " — ЛІВА кнопка «2» (бити)",
                    "R1": " — ПРАВА кнопка «1» зверху (біг)", "R2": " — ПРАВА кнопка «2» (бити)"}.get(n, "")
            s.append({"kind": "btn", "name": n, "text": f"Натисни кнопку «{n}»{hint}"})
        return s

    @staticmethod
    def x_steps():
        return [{"kind": "chord", "text": "Тримай кнопку X (одну кнопку або дві разом) і відпусти"}]

    def _reset(self):
        self.t_step, self.t_move, self.rng, self.wait_release = None, None, {}, True
        self.chord, self.hold_t = set(), None

    @property
    def prompt(self):
        if self.done:
            return "Готово!"
        return f"Крок {self.i + 1} з {len(self.steps)}: {self.steps[self.i]['text']}"

    def skip(self):
        if not self.done:
            self.note = "Пропущено: лишається як було."
            self._next()

    def _next(self):
        self.i += 1
        if self.i >= len(self.steps):
            self.done = True
        else:
            self._reset()

    def feed(self, snap, now):
        if self.done:
            return
        if not snap or not snap.get("connected"):
            self.note = "Геймпад не підключено."
            return
        if self.t_step is None:
            self.t_step = now
        mask, axes, st = snap["buttons"], snap["axes"], self.steps[self.i]
        if self.wait_release:                               # спершу всі кнопки мають бути відпущені
            if mask == 0 or now - self.t_step > 4:
                self.wait_release, self.t_step = False, now
            return
        if now - self.t_step > 20:
            self.note = "Пропущено: нічого не натиснуто."
            self._next()
            return
        kind = st["kind"]
        if kind == "btn":
            used = set(self.res["map"].values())
            for bit in range(32):
                if mask >> bit & 1 and bit not in used:
                    self.res["map"][st["name"]] = bit
                    self.note = f"«{st['name']}» = кнопка {bit + 1} у Windows"
                    self._next()
                    return
        elif kind == "axes":
            taken = set(self.res["axes"].values())
            for a in AXIS_ORDER:
                if a not in taken and a in axes:
                    lo, hi = self.rng.get(a, (axes[a], axes[a]))
                    self.rng[a] = (min(lo, axes[a]), max(hi, axes[a]))
            if self.t_move is None and any(hi - lo > 0.7 for lo, hi in self.rng.values()):
                self.t_move = now
            if self.t_move is not None and now - self.t_move > 2.0:
                top = sorted(((hi - lo, a) for a, (lo, hi) in self.rng.items()), reverse=True)[:2]
                if len(top) == 2 and top[1][0] > 0.7:
                    pair = sorted((a for _, a in top), key=AXIS_ORDER.index)   # горизонталь іде перед вертикаллю
                    self.res["axes"][st["keys"][0]], self.res["axes"][st["keys"][1]] = pair
                    self.note = f"Осі: {pair[0].upper()} і {pair[1].upper()}"
                    self._next()
                else:
                    self.note = "Крути ручку саме по колу, щоб обидві осі зрушили."
                    self.t_move, self.rng = None, {}
        elif kind == "chord":
            bits = {b for b in range(32) if mask >> b & 1}
            if bits:
                self.chord |= bits
                if self.hold_t is None:
                    self.hold_t = now
            elif self.chord:
                if now - self.hold_t > 0.35:
                    names = [n for n, b in self.base_map.items() if b in self.chord]
                    if names:
                        self.res["x"] = sorted(names, key=BTN_ORDER.index)
                        self.note = "X = " + " + ".join(self.res["x"])
                        self._next()
                        return
                    self.note = "Ці кнопки не з відомих. Спершу навчи геймпад."
                self.chord, self.hold_t = set(), None


# ------------------------------------------------------------------ двигун: читає геймпад і керує грою
def _is_game(title):
    return "vice city" in title and "жека" not in title


class PadEngine(threading.Thread):
    """Читає геймпад ~120 разів на секунду. Режим «гра»: кнопки -> клавіші, права ручка -> мишка (камера),
    ліва -> стрілки, хрестовина -> радіо. Режим «комп'ютер» (X): ліва ручка -> курсор, 1 / 2 -> клік мишкою."""

    def __init__(self, app, inject, helpers):
        super().__init__(daemon=True)
        self.app, self.inject, self.h = app, inject, helpers
        self.joy, self.radio = Joy(), Radio()
        self.mode, self.learning = "game", False
        self.snap = {"connected": False, "name": "", "buttons": 0, "axes": {}, "pov": -1}
        self.cmds, self.events = collections.deque(), collections.deque(maxlen=64)
        self.held, self.timers, self.mouse_down = {}, [], set()
        self.prev, self.consumed, self.special = set(), set(), set()
        self.dirs, self.pov_prev, self.pov_t = set(), set(), 0.0
        self.acc, self.scroll = [0.0, 0.0], 0.0
        self.fg, self.fg_t, self.radio_t, self.tap_n = (False, False), 0.0, 0.0, 0
        self.osd_text = ""

    # --- зв'язок з інтерфейсом
    def cmd(self, name, arg=None):
        self.cmds.append((name, arg))

    def radio_dir(self):
        d = self.app.settings.get("radio_dir") or ""
        return d if d else os.path.join(self.h["app_dir"], "radio")

    def panel_state(self, aid):
        if aid == "padmode":
            return "КОМП'ЮТЕР" if self.mode == "pc" else "гра"
        if aid == "radio":
            return self.radio.label()
        return ""

    def pump(self):
        """Викликається з потоку Tk: показує підказки й керує панеллю."""
        try:
            while self.events:
                ev = self.events.popleft()
                panel = getattr(self.app, "panel", None)
                if ev[0] == "osd":
                    self.h["osd"](ev[1], ev[2] if len(ev) > 2 else "")
                elif ev[0] == "panel" and panel and panel.visible:
                    {"up": lambda: panel.move(-1), "down": lambda: panel.move(1), "ok": panel.activate}[ev[1]]()
                elif ev[0] == "redraw" and panel and panel.visible:
                    panel.redraw()
                elif ev[0] == "mainmenu":
                    mm = getattr(self.app, "mainmenu", None)
                    if mm:
                        mm.toggle()
                elif ev[0] == "trainer":
                    self.app.toggle_visible()
        except Exception:
            pass
        finally:
            self.app.after(60, self.pump)

    def osd(self, title, sub=""):
        self.events.append(("osd", title, sub))

    def begin(self):
        s = self.app.settings
        if s.get("pad_map") == OLD_MAP:                       # стара розкладка за замовчуванням (L2/R2 перед L1/R1) -> типова
            s["pad_map"] = dict(DEFAULT_MAP)
            self.h["save"](s)
        self.radio.vol = int(s.get("radio_vol", 70))
        self.radio.scan(self.radio_dir())
        self.radio.idx = min(int(s.get("radio_station", 0)), len(self.radio.stations))
        if s.get("pad_radio_native", True):                  # музика грає в рідному радіо гри, власний плеєр мовчить
            self.radio.idx = 0
        self.start()
        self.app.after(500, self.pump)

    # --- клавіші
    def spec(self, action):
        s = (self.app.settings.get("pad_keys") or {}).get(action)
        return s if isinstance(s, dict) and ("scan" in s or "wheel" in s) else DEFAULT_KEYS[action]

    def key_down(self, spec, owner):
        k = (spec["scan"], bool(spec.get("ext")))
        owners = self.held.setdefault(k, set())
        if not owners:
            key_event(k[0], k[1], False)
        owners.add(owner)

    def key_up(self, owner):
        for k, owners in list(self.held.items()):
            if owner in owners:
                owners.discard(owner)
                if not owners:
                    key_event(k[0], k[1], True)
                    del self.held[k]

    def later(self, delay, fn):
        self.timers.append((time.time() + delay, fn))

    def tap(self, spec):
        if "wheel" in spec:
            mouse_event(M_WHEEL, data=120 * spec["wheel"])
            return
        self.tap_n += 1
        owner = ("tap", self.tap_n)
        self.key_down(spec, owner)
        self.later(0.07, lambda: self.key_up(owner))     # гра опитує клавіатуру покадрово: тримаємо ~70 мс

    def mouse_btn(self, which, down):
        flags = {"l": (M_LDOWN, M_LUP), "r": (M_RDOWN, M_RUP), "m": (M_MDOWN, M_MUP)}[which]
        if down and which not in self.mouse_down:
            self.mouse_down.add(which)
            mouse_event(flags[0])
        elif not down and which in self.mouse_down:
            self.mouse_down.discard(which)
            mouse_event(flags[1])

    def release_all(self):
        for k in list(self.held):
            key_event(k[0], k[1], True)
        self.held.clear()
        for w in list(self.mouse_down):
            self.mouse_btn(w, False)
        self.dirs, self.pov_prev, self.special = set(), set(), set()
        self.acc, self.scroll = [0.0, 0.0], 0.0

    def set_mode(self, m, quiet=False):
        self.release_all()
        self.mode = m
        if quiet:
            self.events.append(("redraw",))
            return
        self.osd("РЕЖИМ КОМП'ЮТЕРА" if m == "pc" else "РЕЖИМ ГРИ",
                 "ліва ручка — курсор · 1 — ЛКМ · 2 — ПКМ · 3 — Enter · 4 — Esc · права ручка — прокрутка" if m == "pc"
                 else "геймпад знову керує грою")
        self.events.append(("redraw",))

    def toggle_mode(self):
        self.set_mode("pc" if self.mode == "game" else "game")

    # --- команди з інтерфейсу
    def process_cmds(self):
        while self.cmds:
            name, arg = self.cmds.popleft()
            s = self.app.settings
            try:
                if name == "toggle_mode":
                    self.toggle_mode()
                elif name == "set_mode":
                    if arg in ("game", "pc") and arg != self.mode:
                        self.set_mode(arg, quiet=True)
                elif name in ("radio_next", "radio_prev"):
                    self.radio_go(1 if name == "radio_next" else -1)
                elif name == "vol_set":
                    self.radio.set_volume(arg)
                    s["radio_vol"] = self.radio.vol
                    self.h["save"](s)
                elif name == "rescan":
                    n, t = self.radio.scan(self.radio_dir())
                    self.osd("Радіо: " + (f"станцій {n}, пісень {t}" if n else "у папці radio немає музики"),
                             self.radio_dir())
                    self.events.append(("redraw",))
                elif name == "radio_off":
                    self.radio.tune(0)
            except Exception:
                pass

    def radio_go(self, d):
        text = self.radio.step(d, bool(self.app.settings.get("radio_live", True)))
        self.app.settings["radio_station"] = self.radio.idx
        self.h["save"](self.app.settings)
        self.osd(text, ("♪ " + self.radio.track) if self.radio.track else "")
        self.events.append(("redraw",))

    def radio_vol(self, d):
        self.radio.set_volume(self.radio.vol + d)
        self.app.settings["radio_vol"] = self.radio.vol
        self.h["save"](self.app.settings)
        self.osd(f"Гучність радіо: {self.radio.vol}%")

    # --- головний цикл
    def run(self):
        last = time.time()
        while True:
            try:
                self.process_cmds()
                now = time.time()
                dt, last = min(now - last, 0.05), now
                for t in [t for t in self.timers if t[0] <= now]:
                    self.timers.remove(t)
                    t[1]()
                s = self.app.settings
                if not s.get("pad_on", True):
                    self.release_all()
                    self.snap = {"connected": False, "name": "вимкнено", "buttons": 0, "axes": {}, "pov": -1}
                    self.radio_tick(now)
                    time.sleep(0.25)
                    continue
                st = self.joy.poll()
                if st is None:
                    if self.snap["connected"]:
                        self.release_all()
                        self.prev = set()
                    self.snap = {"connected": False, "name": "", "buttons": 0, "axes": {}, "pov": -1}
                    self.radio_tick(now)
                    time.sleep(0.2)
                    continue
                self.snap = {"connected": True, "name": self.joy.name, **st}
                if not self.learning:
                    self.handle(st, dt, now)
                else:
                    self.release_all()
                self.radio_tick(now)
            except Exception:
                time.sleep(0.05)
            time.sleep(0.008)

    def fg_state(self, now):
        if now - self.fg_t > 0.12:
            self.fg_t = now
            t = self.h["fg_title"]()
            self.fg = (_is_game(t), _is_game(t) or "жека" in t)
        return self.fg

    def radio_tick(self, now):
        if now - self.radio_t < 0.4:
            return
        self.radio_t = now
        active = True
        if self.app.settings.get("radio_game_only", True):
            active = self.fg_state(now)[0] and not getattr(self.app, "paused", False)
        self.radio.tick(active)

    def handle(self, st, dt, now):
        s = self.app.settings
        m = s.get("pad_map") or DEFAULT_MAP
        P = {n for n, b in m.items() if st["buttons"] >> b & 1}
        newly, rel = P - self.prev, self.prev - P
        # --- «кнопка X»: комбінація (за замовчуванням SELECT + START) перемикає режим гра ↔ комп'ютер
        xs = set(s.get("pad_x") or DEFAULTS["pad_x"]) & set(m)
        if xs and xs <= P and not xs <= self.prev:
            self.consumed |= xs
            self.toggle_mode()
        if {"L3", "R3"} <= P and not {"L3", "R3"} <= self.prev:      # L3 + R3 = меню «Жека Сіті» (як F9)
            self.consumed |= {"L3", "R3"}
            self.events.append(("mainmenu",))
        was = set(self.consumed)
        self.consumed = {b for b in self.consumed if b in P}
        newly -= was
        if now < self.inject["until"]:                    # трейнер сам вводить чит-код: не заважаємо
            self.prev = P
            return
        ax = s.get("pad_axes") or DEFAULT_AXES
        lx, ly = st["axes"].get(ax["lx"], 0.0), st["axes"].get(ax["ly"], 0.0)
        rx, ry = st["axes"].get(ax["rx"], 0.0), st["axes"].get(ax["ry"], 0.0)
        dz = max(0.05, min(0.6, s.get("pad_dead", 22) / 100.0))
        pov = pov_dirs(st["pov"])
        if self.mode == "pc":
            self.handle_pc(P, newly, rel, was, lx, ly, ry, pov, dz, dt)
        else:
            self.handle_game(P, newly, rel, was, lx, ly, rx, ry, pov, dz, dt, now)
        self.prev = P

    # --- режим «комп'ютер»
    def handle_pc(self, P, newly, rel, was, lx, ly, ry, pov, dz, dt):
        s = self.app.settings
        sp = s.get("pad_cursor", 10) * 110.0                   # пікселів за секунду при повному відхиленні
        self.acc[0] += curve(lx, dz) * sp * dt
        self.acc[1] += curve(ly, dz) * sp * dt
        mx, my = int(self.acc[0]), int(self.acc[1])
        if mx or my:
            self.acc[0] -= mx
            self.acc[1] -= my
            cursor_move(mx, my)
        self.scroll += -curve(ry, dz) * dt * 14.0
        n = int(self.scroll)
        if n:
            self.scroll -= n
            mouse_event(M_WHEEL, data=120 * n)
        if "1" in newly:
            self.mouse_btn("l", True)
        if "2" in newly:
            self.mouse_btn("r", True)
        if "1" in rel:
            self.mouse_btn("l", False)
        if "2" in rel:
            self.mouse_btn("r", False)
        if "3" in newly:
            self.tap(K(0x1C, "Enter"))
        if "4" in newly:
            self.tap(K(0x01, "Esc"))
        if "START" in rel and "START" not in was:
            self.events.append(("trainer",))
        for d in ("up", "down", "left", "right"):                # хрестовина = стрілки
            if d in pov and d not in self.pov_prev:
                self.key_down(self.spec(d), "pov:" + d)
            elif d not in pov and d in self.pov_prev:
                self.key_up("pov:" + d)
        self.pov_prev = set(pov)

    # --- режим «гра»
    def handle_game(self, P, newly, rel, was, lx, ly, rx, ry, pov, dz, dt, now):
        s = self.app.settings
        game, _ = self.fg_state(now)
        if not game:                                           # поза грою нічого не тиснемо
            self.release_all()
            return
        panel = getattr(self.app, "panel", None)
        pvis = bool(panel and panel.visible)
        for b in newly:
            if b in ("L2", "R2"):
                self.key_down(self.spec("attack"), b)
            elif b == "R1":
                self.key_down(self.spec("sprint"), b)
            elif b == "L1":
                self.tap(self.spec("radio_off"))
                self.osd("Радіо: перемкнув (вимкнення)")
            elif b == "1":
                if pvis:
                    self.events.append(("panel", "ok"))
                elif "SELECT" in P:
                    self.special.add(b)
                    self.tap(self.spec("weapon_next"))
                else:
                    self.key_down(self.spec("enter"), b)
            elif b == "3":
                if "SELECT" in P:
                    self.special.add(b)
                    self.tap(self.spec("weapon_prev"))
                else:
                    self.key_down(self.spec("crouch"), b)
            elif b == "2":
                self.key_down(self.spec("sprint"), b)
            elif b == "4":
                self.key_down(self.spec("mission"), b)
        for b in rel:
            self.key_up(b)
            self.special.discard(b)
            if b == "START" and b not in was:
                self.tap(self.spec("menu"))
        # ліва ручка = рух (стрілки), з гістерезисом
        for name, v in (("up", -ly), ("down", ly), ("left", -lx), ("right", lx)):
            on = name in self.dirs
            if not on and v > 0.55:
                self.dirs.add(name)
                self.key_down(self.spec(name), "stick:" + name)
            elif on and v < 0.38:
                self.dirs.discard(name)
                self.key_up("stick:" + name)
        # права ручка = камера (відносний рух мишки)
        if not getattr(self.app, "paused", False) and not pvis:
            sp = s.get("pad_look", 8) * 75.0
            self.acc[0] += curve(rx, dz) * sp * dt
            self.acc[1] += curve(ry, dz) * sp * dt * (-1 if s.get("pad_invert") else 1)
            mx, my = int(self.acc[0]), int(self.acc[1])
            if mx or my:
                self.acc[0] -= mx
                self.acc[1] -= my
                mouse_event(M_MOVE, mx, my)
        # хрестовина (коли світиться ANALOG): ↑ ↓ — вибір зброї, ← → — станції радіо гри.
        # На панелі «Жека Чіц» ↑ ↓ — вибір пункту. SELECT + ↑ ↓ — гучність власного радіо (якщо воно ввімкнене).
        native = bool(s.get("pad_radio_native", True))
        for d in ("left", "right", "up", "down"):
            if d in pov and (d not in self.pov_prev or (d in ("up", "down") and now - self.pov_t > 0.28)):
                self.pov_t = now if d in ("up", "down") else self.pov_t
                if pvis and d in ("up", "down"):
                    self.events.append(("panel", d))
                elif d in ("up", "down") and "SELECT" in P and not native:
                    self.radio_vol(5 if d == "up" else -5)
                    self.consumed.add("SELECT")
                elif d == "up":
                    self.weapon_step(1)
                elif d == "down":
                    self.weapon_step(-1)
                elif native:
                    self.tap(self.spec("radio_prev" if d == "left" else "radio_next"))
                    self.osd("Радіо гри: " + ("◀ попередня станція" if d == "left" else "наступна станція ▶"))
                else:
                    self.radio_go(-1 if d == "left" else 1)
        self.pov_prev = set(pov)

    def weapon_step(self, d):
        """Хрестовина ↑ = наступна зброя, ↓ = попередня (у налаштуваннях можна поміняти клавіші)."""
        if self.app.settings.get("pad_weapon_swap"):
            d = -d
        self.tap(self.spec("weapon_dpad_next" if d > 0 else "weapon_dpad_prev"))


# ------------------------------------------------------------------ допомога для вікна «Налаштування»
def apply_wizard_result(settings, res):
    """Зливає результат майстра «Навчити геймпад» у налаштування (те, що пропущено, лишається як було)."""
    if res.get("map"):
        m = dict(settings.get("pad_map") or DEFAULT_MAP)
        m.update(res["map"])
        settings["pad_map"] = m
    if res.get("axes"):
        a = dict(settings.get("pad_axes") or DEFAULT_AXES)
        a.update(res["axes"])
        settings["pad_axes"] = a
    if res.get("x"):
        settings["pad_x"] = list(res["x"])


_TK_SPECIAL = {
    "Shift_L": (0x2A, False, "Shift лів."), "Shift_R": (0x36, False, "Shift прав."),
    "Control_L": (0x1D, False, "Ctrl лів."), "Control_R": (0x1D, True, "Ctrl прав."),
    "Alt_L": (0x38, False, "Alt лів."), "Alt_R": (0x38, True, "Alt прав."),
    "Caps_Lock": (0x3A, False, "Caps Lock"),
}
_ARROWS = {"Up": "↑", "Down": "↓", "Left": "←", "Right": "→"}
# розширені клавіші: PgUp PgDn End Home стрілки Insert Delete, Num / і Num Lock
_EXT_VK = {0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E, 0x6F, 0x90}


def spec_from_tk_event(e):
    """Подія клавіші Tk -> опис клавіші {scan, ext, name} для SendInput. None, якщо не розпізнано."""
    ks = e.keysym
    if ks in _TK_SPECIAL:
        scan, ext, name = _TK_SPECIAL[ks]
        return K(scan, name, ext)
    if not IS_WIN:
        return None
    vk = e.keycode
    scan = u32.MapVirtualKeyW(vk, 0)                          # MAPVK_VK_TO_VSC
    if not scan:
        return None
    ext = vk in _EXT_VK or ks == "KP_Enter"
    if ks in _ARROWS:
        name = _ARROWS[ks]
    elif len(ks) <= 2:
        name = ks.upper()
    else:
        name = ks.replace("_", " ")
    return K(scan, name, ext)


# ------------------------------------------------------------------ пакет українізації поруч зі скриптом
def _dir_has_gxt(path):
    for root, _, names in os.walk(path):
        if any(n.lower() in ("american.gxt", "english.gxt") for n in names):
            return True
    return False


def _zip_has_gxt(path):
    import zipfile
    try:
        with zipfile.ZipFile(path) as z:
            return any(os.path.basename(n).lower() in ("american.gxt", "english.gxt") for n in z.namelist())
    except Exception:
        return False


def find_local_ukr(app_dir):
    """Шукає готовий пакет: папка ukr\\ (з american.gxt) або .zip у ukr\\ чи поруч зі скриптом."""
    d = os.path.join(app_dir, "ukr")
    if os.path.isdir(d):
        if _dir_has_gxt(d):
            return d
        for n in sorted(os.listdir(d)):
            if n.lower().endswith(".zip") and _zip_has_gxt(os.path.join(d, n)):
                return os.path.join(d, n)
    try:
        names = sorted(os.listdir(app_dir))
    except OSError:
        return ""
    for n in names:
        low = n.lower()
        if low.endswith(".zip") and any(k in low for k in ("ukr", "укр", "ukrain")) and _zip_has_gxt(os.path.join(app_dir, n)):
            return os.path.join(app_dir, n)
    return ""
