# -*- coding: utf-8 -*-
"""
zheka_menu.py — головне меню «Жека Сіті»: назви кнопок, назва гри, підпис версії (тексти GXT)
і колаж-фон/лого у frontend-текстурах (fronten*.txd), тим самим безпечним методом, що й заставка.
Положення кнопок на екрані зашите в exe гри, тут воно НЕ змінюється.
"""
import os
import re
from struct import error as struct_error

import zheka_splash

# що на що міняємо (шукаємо за текстом рядка, без урахування регістру; англ. і рос. локалізації)
BUTTONS = [
    (("start game", "начать игру", "начать новую игру", "новая игра"), "Почати гру"),
    (("options", "settings", "настройки", "опции"), "Налаштування"),
    (("quit game", "exit game", "выйти из игры", "выход из игры", "выход"), "Вийти з гри"),
]
VERSION_TEXT = "Версія Жека і Клео"
# ключі, де гра тримає версію/копірайт на головному екрані меню (якщо є в цьому GXT)
VERSION_KEYS = (b"FEE_VER", b"FEM_VER", b"FEC_VER", b"FEV_VER")
FRONTEND_TXDS = ("fronten1.txd", "fronten2.txd", "fronten_pc.txd")
BG_HINTS = re.compile(r"back|bg|backgr|wall|noise|menu_bg", re.I)
LOGO_HINTS = re.compile(r"logo|title|vc_?city|vicecity", re.I)


def patch_gxt_menu(tables, title=None):
    """tables — результат gxt_parse. Повертає (нові таблиці, список змін). Міняє тільки точні збіги рядків."""
    done = []
    out = []
    for name, ents in tables:
        new_ents = []
        for key, raw in ents:
            txt = raw.decode("utf-16-le", "surrogatepass")
            low = txt.strip().lower()
            repl = None
            for olds, new in BUTTONS:
                if low in olds and name.rstrip(b"\0") == b"MAIN":
                    repl = new
                    break
            if repl is None and key.rstrip(b"\0") in VERSION_KEYS:
                repl = VERSION_TEXT
            if repl is not None and repl != txt:
                done.append((key.rstrip(b"\0").decode("ascii", "ignore"), txt, repl))
                txt = repl
            new_ents.append((key, txt.encode("utf-16-le", "surrogatepass")))
        out.append((name, new_ents))
    return out, done


def find_frontend_files(game_dir):
    found = []
    for root, _, files in os.walk(os.path.join(game_dir, "models")):
        found += [os.path.join(root, f) for f in files if f.lower() in FRONTEND_TXDS]
    return sorted(found)


def scan_txd(data):
    """Список (ім'я, ширина, висота, формат) для діагностики."""
    return [(t.name, t.w, t.h, t.kind) for t in zheka_splash.parse_txd(data)]


def patch_matching(data, pick):
    """Міняє на місці ті текстури, для яких pick(t) повертає картинку. Повертає (нові байти, імена змінених)."""
    texs = zheka_splash.parse_txd(data)
    out = bytearray(data)
    changed = []
    for t in texs:
        img = pick(t)
        if img is None:
            continue
        img = img.resize((t.w, t.h), zheka_splash.Image.LANCZOS)
        pal_img = None
        if t.kind == "pal8":
            q = img.convert("RGB").quantize(256, method=zheka_splash.Image.Quantize.MEDIANCUT,
                                            dither=zheka_splash.Image.Dither.NONE)
            pal_img = q
            pal = zheka_splash.np.zeros((256, 4), zheka_splash.np.uint8)
            pal[:, 3] = 255
            raw = zheka_splash.np.array(q.getpalette()[:768], zheka_splash.np.uint8).reshape(-1, 3)
            pal[:len(raw), :3] = raw
            out[t.pal:t.pal + 1024] = pal.tobytes()
        for k in range(t.mips):
            off, size = t.levels[k]
            block = zheka_splash.encode(img, t, k, pal_img)
            if len(block) != size:
                raise ValueError("Розмір закодованого рівня не збігся.")
            out[off:off + size] = block
        changed.append(t.name)
    res = bytes(out)
    if len(res) != len(data):
        raise ValueError("Перевірка структури не пройшла.")
    return res, changed


def patch_frontend_txd(data, background, logo=None):
    """Фон меню (текстури з назвою про фон). Лого НЕ чіпаємо (logo лишився в сигнатурі для сумісності)."""
    return patch_matching(data, lambda t: background if BG_HINTS.search(t.name) and t.w >= 128 and t.h >= 128 else None)


EXIT_HINTS = re.compile(r"love|exit|quit|bye|thank|postcard|greet|outro|vcity|vicecity", re.I)
SKIP_FILES = re.compile(r"^(fronten|splash|loadsc|gta3|gta_int|generic|particle|hud|misc|player|weapons|vehicles)", re.I)


def scan_models(game_dir, limit_mb=14):
    """Список (файл, [(ім'я, w, h)]) для текстур у models\\*.txd — для діагностики й пошуку екрана виходу."""
    res = []
    base = os.path.join(game_dir, "models")
    for root, dirs, files in os.walk(base):
        if root[len(base):].count(os.sep) >= 2:
            dirs[:] = []
        for f in sorted(files):
            if not f.lower().endswith(".txd"):
                continue
            p = os.path.join(root, f)
            try:
                if os.path.getsize(p) > limit_mb * 1024 * 1024:
                    continue
                with open(p, "rb") as fh:
                    data = fh.read()
                res.append((p, [(t.name, t.w, t.h) for t in zheka_splash.parse_txd(data)]))
            except (OSError, ValueError, struct_error):
                continue
    return res


def find_exit_textures(inv):
    """З інвентаря вибирає файли, де є велика текстура 4:3 з назвою про «з любов'ю / вихід»."""
    out = []
    for p, texs in inv:
        if SKIP_FILES.search(os.path.basename(p)):
            continue
        hits = [n for n, w, h in texs if EXIT_HINTS.search(n) and w >= 512 and h >= 384 and 1.2 <= w / h <= 1.5]
        if hits:
            out.append((p, hits))
    return out


def build_logo(size=(512, 128), text=("ЖЕКА СІТІ",)):
    """Маленький напис «Жека Сіті» (текст шрифтом, не картинка): тло як у меню, літери займають лише половину ширини."""
    from PIL import Image, ImageDraw
    w, h = size
    S = 2
    im = Image.new("RGB", (w * S, h * S), (24, 10, 48))
    d = ImageDraw.Draw(im)
    t = text[0]
    fs = h * S * 0.30
    f = zheka_splash._font(zheka_splash.FONTS_BLACK, fs)
    while d.textlength(t, font=f) > w * S * 0.50 and fs > 8:
        fs *= 0.92
        f = zheka_splash._font(zheka_splash.FONTS_BLACK, fs)
    d.text((w * S / 2, h * S / 2), t, font=f, fill=(255, 255, 255), anchor="mm",
           stroke_width=max(2, int(fs / 14)), stroke_fill=(255, 120, 40))
    return im.resize(size, Image.LANCZOS)


def build_background(collage=None, size=(1024, 768)):
    """Фон усіх екранів рідного меню (Нова гра, Завантажити, Налаштування…) у стилі меню «Жека Сіті»:
    темно-фіолетовий градієнт, діагональні смуги, колаж ледь помітний. Текст гри (рожевий з чорною обводкою)
    читається на будь-якому екрані."""
    from PIL import Image, ImageDraw, ImageEnhance, ImageOps
    w, h = size
    im = Image.new("RGB", size)
    d = ImageDraw.Draw(im)
    for y in range(h):
        t = y / (h - 1)
        d.line([(0, y), (w, y)], fill=(int(18 + 40 * t), int(8 + 6 * t), int(40 + 30 * t)))
    for i in range(0, w + h, 48):
        d.line([(i, 0), (i - h, h)], fill=(34, 14, 64), width=2)
    if collage is not None:
        pic = ImageOps.fit(collage.convert("RGB"), size, Image.LANCZOS)
        pic = ImageEnhance.Brightness(pic).enhance(0.55)
        im = Image.blend(im, pic, 0.22)
    d = ImageDraw.Draw(im)
    d.rectangle([6, 6, w - 7, h - 7], outline=(255, 120, 170), width=5)     # рожева рамка, як на кнопках
    return im
